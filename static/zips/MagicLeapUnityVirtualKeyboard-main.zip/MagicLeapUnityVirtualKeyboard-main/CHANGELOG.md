## [0.1.0-alpha] - 2022-03-31
### Added
- This implementation as a Unity package

## [0.1.1-alpha] - 2022-04-01
### Fixed
- Fixed an error of script name in README

## [0.1.2-alpha] - 2022-04-05
### Fixed
- Fixed an error in explaining the keyboard interaction logic in README
- Improved the explanation of how double-click is detected in README
