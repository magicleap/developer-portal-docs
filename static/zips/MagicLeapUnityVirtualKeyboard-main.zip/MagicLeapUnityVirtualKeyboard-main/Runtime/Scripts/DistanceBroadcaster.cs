﻿// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    public class DistanceBroadcaster : MonoBehaviour
    {
        public List<DistanceReceiver> ActiveReceivers = new List<DistanceReceiver>();
        public List<DistanceReceiverPlane> ActiveReceiverPlanes = new List<DistanceReceiverPlane>();

        public void ClearActiveReceivers()
        {
            ActiveReceivers.Clear();
            ActiveReceiverPlanes.Clear();
        }

        public void AddActiveReceiver(DistanceReceiver receiver)
        {
            ActiveReceivers.Add(receiver);
            if (receiver is DistanceReceiverPlane)
            {
                ActiveReceiverPlanes.Add((DistanceReceiverPlane)receiver);
            }
        }
        
        private void Awake()
        {
            DistanceMaster.AddBroadcaster(this);
        }

        private void OnDestroy()
        {
            DistanceMaster.RemoveBroadcaster(this);
        }

    }
}
