// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ExampleConnector : MonoBehaviour
{
    [SerializeField] private TextMeshPro _info;

    public void KeyEventHandler(string justTyped, MagicLeap.Keyboard.KeyType keyType, bool doubleClick, string allTyped)
    {
        string toPrint = "Just typed: " + justTyped + "\n" +
                         "KeyType: " + keyType + "\n" +
                         "Double click?: " + doubleClick + "\n\n" +
                         "All typed content: " + allTyped;
        _info.text = toPrint;
        Debug.Log(toPrint);
    }
}