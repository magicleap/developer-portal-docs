﻿// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace MagicLeap.Keyboard
{
    public abstract class DistanceReceiver : MonoBehaviour
    {
        public float AquireDistance = 0.2f;

        protected Collider Collider = null;
        protected List<DistanceBroadcaster> ActiveBroadcasters = new List<DistanceBroadcaster>();
        
        public void ClearActiveBroadcasters()
        {
            ActiveBroadcasters.Clear();
        }

        public void AddActiveBroadcaster(DistanceBroadcaster broadcaster)
        {
            ActiveBroadcasters.Add(broadcaster);
        }

        // Returns the closest point to p on the receiver
        public abstract Vector3 GetPos(Vector3 p);

        // Returns the distance from p to the cloeset point on the receiver
        public abstract float GetDistance(Vector3 p);
        
        private void Awake()
        {
            DistanceMaster.AddReceiver(this);
        }
        private void OnDestroy()
        {
            DistanceMaster.RemoveReceiver(this);
        }


    }
}

