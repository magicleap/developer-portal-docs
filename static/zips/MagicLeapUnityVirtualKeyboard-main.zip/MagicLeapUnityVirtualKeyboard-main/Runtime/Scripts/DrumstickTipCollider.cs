// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    public class DrumstickTipCollider : MonoBehaviour
    {
        [SerializeField] private InteractionManager _interactionManager;

        void OnTriggerEnter(Collider other)
        {
            if (other.GetComponent<Clickable>())
            {
                _interactionManager.EnterClickCollider(other);
            }

            if (other.GetComponent<Grabbable>())
            {
                _interactionManager.EnterGrabCollider(other);
            }
        }

        void OnTriggerExit(Collider other)
        {
            if (other.GetComponent<Clickable>())
            {
                _interactionManager.ExitClickCollider(other);
            }

            if (other.GetComponent<Grabbable>())
            {
                _interactionManager.ExitGrabCollider(other);
            }
        }
    }
}
