// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    public enum ShiftKeyState
    {
        Off,
        OnTemp,
        OnPerm
    }

    public class ShiftKeyBehavior : MonoBehaviour
    {
        [SerializeField]
        private Renderer _iconRend;
        
        [SerializeField]
        private Renderer _fillRend;

        [SerializeField]
        private Material _iconMatOff;
        
        [SerializeField]
        private Material _iconMatOn;

        [SerializeField]
        private Material _fillMatOff;
        
        [SerializeField]
        public Material _fillMatOn;

        public void SwitchStatus(ShiftKeyState keyState)
        {
            switch(keyState)
            {
                case ShiftKeyState.Off:
                    _iconRend.material = _iconMatOff;
                    _fillRend.material = _fillMatOff;
                    break;
                case ShiftKeyState.OnTemp:
                    _iconRend.material = _iconMatOn;
                    _fillRend.material = _fillMatOff;
                    break;
                case ShiftKeyState.OnPerm:
                    _iconRend.material = _iconMatOn;
                    _fillRend.material = _fillMatOn;
                    break;
                default:
                    break;
            }
        }

        void Awake()
        {
            if (_fillRend == null || _iconRend == null)
            {
                Debug.LogError("_fillRend and _iconRend should not be null, " +
                               "they need to be hard-referenced in the Editor");
            }
        }
    }
}
