﻿// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace MagicLeap.Keyboard
{
    public class Targetable : MonoBehaviour
    { 
        public UnityEvent OnTargetEnter;
        public UnityEvent OnTargetExit;
        
        private bool _isTargeted = false;

        public void TargetEnter()
        {
            if (!_isTargeted)
            {
                OnTargetEnter.Invoke();
                _isTargeted = true;
            }
        }

        public void TargetExit()
        {
            if (_isTargeted)
            {
                OnTargetExit.Invoke();
                _isTargeted = false;
            }
        }

        protected void OnDisable()
        {
            if(_isTargeted)
            {
                TargetExit();
            }
        }
    }
}
