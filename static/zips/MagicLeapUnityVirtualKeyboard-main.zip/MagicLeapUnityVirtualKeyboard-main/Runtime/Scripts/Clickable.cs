// Copyright(c) 2019 - present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;

namespace MagicLeap.Keyboard
{
    public class Clickable : MonoBehaviour
    {
        public UnityEvent OnClicked;
        public UnityEvent OnUnClicked;
        public UnityEvent OnDoubleClicked;
        
        public bool CanClick = true;
        
        public float MotionRangeZStart = 0.0f;
        
        public float MotionRangeZEnd = 0.004f;
        
        public float FrontSideDetectThreshold = 0.01f;
        
        public BoxCollider Collider;
        
        public bool IsBeingClicked = false;
        
        [Tooltip("Time to make this button unclickable at boot up (s)")]
        public float BootupDisableTime = 0.1f;
        
        [Tooltip("Detection window for double click (s); double click is disabled if < 0.0f")]
        public float DoubleClickReactWindow = -1.0f;
        
        [Tooltip("Time interval of repeated click by keeping the key inside collider (s)")]
        public float StayToRepeatInterval = 0.3f;

        // If double click is disabled, this is the activation delay
        // If double click is enabled, this is the extra delay on top of
        // the delay introduced by waiting for double click 
        // 0.1f by default, this gives the key enough time to finish the color changing animation
        [Tooltip("Extra delay in activating single click (s) ")]
        public float SingleClickExtraDelay = 0.1f;
        
        [Tooltip("Delay in activating double click (s)")]
        public float DoubleClickDelay = 0.1f;

        [SerializeField]
        private bool _printDebugInfo = false;

        [SerializeField]
        private GameObject _toMoveObj;

        [SerializeField]
        private AnimateMaterialFloat _fillMeshAnimateMaterialFloat;

        private IEnumerator _bootupDisableProc = null;
        private IEnumerator _firstClickProc = null;
        private IEnumerator _stayToRepeatProc = null;

        public void Click()
        {
            if (!CanClick || IsBeingClicked)
            {
                return;
            }

            if (_fillMeshAnimateMaterialFloat)
            {
                _fillMeshAnimateMaterialFloat.PlayForward();
            }

            IsBeingClicked = true;

            // If double click is disabled
            if (DoubleClickReactWindow <= 0.0f) 
            {
                // If no delayed activation
                if (SingleClickExtraDelay <= 0.0f) 
                {
                    if (_printDebugInfo)
                    {
                        Debug.Log("Single click activated on button");
                    }
                    OnClicked.Invoke();
                    StartRepeatProc();
                }
                else
                {
                    StartCoroutine(DelayedActivateProc(false));
                }
            }
            // Double click enabled
            else 
            {
                // We are within the window of waiting for the second click
                if (_firstClickProc != null) 
                {
                    StopCoroutine(_firstClickProc);
                    _firstClickProc = null;
                    // If double click delay is disabled
                    if (DoubleClickDelay <= 0.0f) 
                    {
                        if (_printDebugInfo)
                        {
                            Debug.Log("Double click activated on button");
                        }
                        OnDoubleClicked.Invoke();
                    }
                    else
                    {
                        StartCoroutine(DelayedActivateProc(true));
                    }
                }
                // We start a fresh new "first click"
                else 
                {
                    _firstClickProc = FirstClickProc();
                    StartCoroutine(_firstClickProc);
                }
            }
        }

        public void UnClick()
        {
            if (IsBeingClicked)
            {
                if (_stayToRepeatProc != null) 
                {
                    StopCoroutine(_stayToRepeatProc);
                    _stayToRepeatProc = null;
                }
                IsBeingClicked = false;
                OnUnClicked.Invoke();
            }
        }

        public void UpdateKeyPos(Vector3 drumStickPos, bool reset = false)
        {
            if (reset || !IsBeingClicked)
            {
                _toMoveObj.transform.localPosition = Vector3.zero;
            }
            else
            {
                Vector3 drumStickPosLocal = transform.InverseTransformPoint(drumStickPos);
                float depth = Mathf.Clamp(drumStickPosLocal.z, MotionRangeZStart, MotionRangeZEnd);
                _toMoveObj.transform.localPosition = new Vector3(0.0f, 0.0f, depth);
            }
        }

        private void OnEnable()
        {
            if (BootupDisableTime > 0.0f)
            {
                CanClick = false;
                _bootupDisableProc = BootupDisableProc();
                StartCoroutine(_bootupDisableProc);
            }
            else
            {
                CanClick = true;
            }
            
            _firstClickProc = null;
            _stayToRepeatProc = null;
        }

        private void Awake()
        {
            if (Collider == null || _fillMeshAnimateMaterialFloat == null)
            {
                Debug.LogError("Collider and _fillMeshAnimateMaterialFloat should not be null, " +
                               "they need to be hard-referenced in the Editor");
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.matrix = transform.localToWorldMatrix;

            // Draw the motion range of key
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireCube(
                Vector3.forward * (MotionRangeZEnd - MotionRangeZStart) * 0.5f,
                new Vector3(Collider.size.x, Collider.size.y, MotionRangeZEnd - MotionRangeZStart)
            );

            // Draw the zone in which entering the collider is considered as
            // a valid click coming from the front of the key
            Gizmos.color = Color.magenta;
            Gizmos.DrawWireCube(
                Vector3.forward * FrontSideDetectThreshold * 0.5f,
                new Vector3(Collider.size.x, Collider.size.y, FrontSideDetectThreshold)
            );
        }

        protected void OnDisable()
        {
            if(IsBeingClicked)
            {
                UnClick();
            }
            StopAllCoroutines();
            _bootupDisableProc = null;
            _firstClickProc = null;
            _stayToRepeatProc = null;
        }

        private IEnumerator BootupDisableProc()
        {
            yield return new WaitForSeconds(BootupDisableTime);
            CanClick = true;
        }

        private IEnumerator FirstClickProc()
        {
            yield return new WaitForSeconds(DoubleClickReactWindow); // wait for the "second click" in this window
            if (SingleClickExtraDelay <= 0.0f) // if no delayed activation
            {
                if (_printDebugInfo)
                {
                    Debug.Log("Single click activated on button");
                }
                OnClicked.Invoke();
                StartRepeatProc();
            }
            else
            {
                StartCoroutine(DelayedActivateProc(false));
            }
            _firstClickProc = null;
        }

        private IEnumerator StayToRepeatProc()
        {
            while(true)
            {
                yield return new WaitForSeconds(StayToRepeatInterval);

                if (_fillMeshAnimateMaterialFloat)
                {
                    _fillMeshAnimateMaterialFloat.PlayForward();
                }

                if (_printDebugInfo)
                {
                    Debug.Log("Single click activated on button");
                }

                OnClicked.Invoke();
            }
        }

        private IEnumerator DelayedActivateProc(bool doubleClick)
        {
            if (doubleClick)
            {
                yield return new WaitForSeconds(DoubleClickDelay);
                if (isActiveAndEnabled)
                {
                    if (_printDebugInfo)
                    {
                        Debug.Log("Double click activated on button");
                    }
                    OnDoubleClicked.Invoke();
                }
            }
            else
            {
                yield return new WaitForSeconds(SingleClickExtraDelay);
                if (isActiveAndEnabled)
                {
                    if (_printDebugInfo)
                    {
                        Debug.Log("Single click activated on button");
                    }
                    OnClicked.Invoke();
                    StartRepeatProc();
                }
            }
        }

        private void StartRepeatProc()
        {
            // If the drumstick is still staying inside
            if (IsBeingClicked) 
            {
                if (_stayToRepeatProc != null) // sanity check
                {
                    Debug.LogError("_stayToRepeatProc should not have value here, something went wrong");
                    StopCoroutine(_stayToRepeatProc);
                    _stayToRepeatProc = null;
                }
                _stayToRepeatProc = StayToRepeatProc();
                StartCoroutine(_stayToRepeatProc);
            }
        }
    }
}
