// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace MagicLeap.Keyboard
{
    public enum InputType
    {
        Raycast,
        Drumstick
    }

    public enum InputTypeEnabled
    {
        Both,
        RaycastOnly,
        DrumstickOnly
    }

    public class InteractionManager : MonoBehaviour
    {
        [SerializeField] private bool _printDebugInfo = false;

        [Tooltip("Which interaction type(s) are enabled")]
        [SerializeField] private InputTypeEnabled _inputTypeEnabled = InputTypeEnabled.Both;
        
        [Tooltip("Distance threshold to switch between raycasting and drumstick if both are enabled")]
        [SerializeField] private float _switchDist = 0.2f;

        [SerializeField] private GameObject _drumstickTip;
        [SerializeField] private GameObject _drumstickMeshes;
        [SerializeField] private DistanceBroadcaster _distBroadcaster;

        [SerializeField] private GameObject _raycasterObj;
        [SerializeField] private Raycaster _raycaster;
        
        private bool _interactionEnabled = true;
        private InputType _inputType = InputType.Drumstick;
        private GameObject _targetKeyObj;
        private GameObject _beingClickedKeyObj;

        private GameObject _closestTargetableKey;
        private float _closestTargetableKeyDist;

        private GameObject _targetHandle;
        private GameObject _grabbedHandle;

        public void EnterClickCollider(Collider other)
        {
            if (_printDebugInfo)
            {
                Debug.Log("Entered key collider");
            }

            if (_inputType != InputType.Drumstick)
            {
                return;
            }

            GameObject keyObj = other.gameObject;
            Clickable clickable = keyObj.GetComponent<Clickable>();
            if (!clickable)
            {
                return;
            }

            Vector3 drumStickPosLocal = keyObj.transform.InverseTransformPoint(_drumstickTip.transform.position);
            
            // Prevent click when coming from back of the key
            if (!clickable.IsBeingClicked && clickable.CanClick && clickable.Collider &&
                drumStickPosLocal.z < clickable.FrontSideDetectThreshold)
            {
                if (_printDebugInfo)
                {
                    Debug.Log("Clicked");
                }

                clickable.Click();
                _beingClickedKeyObj = keyObj;
            }
        }

        public void ExitClickCollider(Collider other)
        {
            if (_printDebugInfo)
            {
                Debug.Log("Exited key collider");
            }

            if (_inputType != InputType.Drumstick)
            {
                return;
            }

            GameObject keyObj = other.gameObject;
            Clickable clickable = keyObj.GetComponent<Clickable>();
            if (!clickable)
            {
                return;
            }

            if (clickable.IsBeingClicked)
            {
                if (_printDebugInfo)
                {
                    Debug.Log("Unclicked");
                }

                clickable.UpdateKeyPos(_drumstickTip.transform.position, true);
                clickable.UnClick();
                _beingClickedKeyObj = null;
            }
        }

        public void EnterGrabCollider(Collider other)
        {
            if (_printDebugInfo)
            {
                Debug.Log("Entered grabbable collider");
            }

            if (_inputType != InputType.Drumstick)
            {
                return;
            }

            _targetHandle = other.gameObject;
            other.GetComponent<Targetable>()?.TargetEnter();
        }

        public void ExitGrabCollider(Collider other)
        {
            if (_printDebugInfo)
            {
                Debug.Log("Exited grabbable collider");
            }

            if (_inputType != InputType.Drumstick)
            {
                return;
            }

            _targetHandle = null;
            other.GetComponent<Targetable>()?.TargetExit();
        }

        public void EnableInteraction(bool enable)
        {
            if (enable && !_interactionEnabled)
            {
                _drumstickTip.SetActive(true);
                _raycasterObj.SetActive(_inputType == InputType.Raycast ? true : false);
                _interactionEnabled = true;
            }
            else if (!enable && _interactionEnabled)
            {
                _drumstickTip.SetActive(false);
                _raycasterObj.SetActive(_inputType == InputType.Raycast ? true : false);
                _interactionEnabled = false;
            }
        }

        void Start()
        {
            _inputType = DetermineInputType();
            SwitchInputType(_inputType);
        }

        void Update()
        {
            if (!_interactionEnabled)
            {
                return;
            }

            if (_beingClickedKeyObj)
            {
                _beingClickedKeyObj.GetComponent<Clickable>().UpdateKeyPos(_drumstickTip.transform.position);
            }
        }

        void FixedUpdate()
        {
            if (!_interactionEnabled)
            {
                return;
            }
            
            // Register all the broadcasters and receivers
            DistanceMaster.Tick();
            
            GetClosestTargetableKey();

            InputType nextInputType = DetermineInputType();

            if (nextInputType != _inputType)
            {
                SwitchInputType(nextInputType);
            }

            if (_inputType == InputType.Drumstick)
            {
                FixedUpdateDrumstick();
            }
            else if (_inputType == InputType.Raycast)
            {
                FixedUpdateRaycast();
            }
        }

        private InputType DetermineInputType()
        {
            float distToKeyboard = _closestTargetableKeyDist; // TODO ryu: this can be improved

            InputType nextInputType;
            switch (_inputTypeEnabled)
            {
                case InputTypeEnabled.Both:
                    nextInputType = distToKeyboard < _switchDist ? InputType.Drumstick : InputType.Raycast;
                    break;
                case InputTypeEnabled.DrumstickOnly:
                    nextInputType = InputType.Drumstick;
                    break;
                case InputTypeEnabled.RaycastOnly:
                    nextInputType = InputType.Raycast;
                    break;
                default:
                    nextInputType = InputType.Raycast;
                    break;
            }

            return nextInputType;
        }

        private void SwitchInputType(InputType inputType)
        {
            // Clean up before switching on inputType
            if (_targetKeyObj)
            {
                _targetKeyObj.GetComponent<Targetable>()?.TargetExit();
                _targetKeyObj = null;
            }
            
            if (_beingClickedKeyObj)
            {
                _beingClickedKeyObj.GetComponent<Clickable>()?.UnClick();
                _beingClickedKeyObj = null;
            }

            // Now switch
            if (inputType == InputType.Drumstick)
            {
                _raycaster.enabled = false;
                _raycasterObj.SetActive(false);
                _drumstickMeshes.SetActive(true);
            }
            else if (inputType == InputType.Raycast)
            {
                _raycaster.enabled = true;
                _raycasterObj.SetActive(true);
                _drumstickMeshes.SetActive(false);
            }
            _inputType = inputType;
        }
        
        // Drumstick is the interaction mode
        private void FixedUpdateDrumstick() 
        {
            // If we are in the collider for grabbable handle, cancel the target key
            if (_targetHandle)
            {
                if (_targetKeyObj)
                {
                    _targetKeyObj.GetComponent<Targetable>()?.TargetExit();
                    _targetKeyObj = null;
                }
            }
            // Otherwise we consider keys as targets
            else if (_closestTargetableKey != _targetKeyObj) 
            {
                if (_targetKeyObj)
                {
                    _targetKeyObj.GetComponent<Targetable>()?.TargetExit();
                }

                _targetKeyObj = _closestTargetableKey;

                if (_targetKeyObj)
                {
                    _targetKeyObj.GetComponent<Targetable>()?.TargetEnter();
                }
            }
        }
        
        // Ray casting is the interaction mode
        private void FixedUpdateRaycast() 
        {
            // Try targeting key
            if (_raycaster.RaycastHitObj != _targetKeyObj)
            {
                if (_targetKeyObj)
                {
                    _targetKeyObj.GetComponent<Targetable>()?.TargetExit();
                }

                if (!_raycaster.RaycastHitObj ||
                    !_raycaster.RaycastHitObj.GetComponent<KeyInfo>())
                {
                    _targetKeyObj = null;
                }
                else
                {
                    _targetKeyObj = _raycaster.RaycastHitObj;
                }

                if (_targetKeyObj)
                {
                    _targetKeyObj.GetComponent<Targetable>()?.TargetEnter();
                }
            }
            
            // Try targeting handle
            if (_raycaster.RaycastHitObj != _targetHandle) 
            {
                if (_targetHandle)
                {
                    _targetHandle.GetComponent<Targetable>()?.TargetExit();
                }

                if (!_raycaster.RaycastHitObj ||
                    !_raycaster.RaycastHitObj.GetComponent<Grabbable>())
                {
                    _targetHandle = null;
                }
                else
                {
                    _targetHandle = _raycaster.RaycastHitObj;
                }

                if (_targetHandle && _targetHandle.GetComponent<Grabbable>())
                {
                    _targetHandle.GetComponent<Targetable>()?.TargetEnter();
                }
            }
        }

        // O(n) pass to pick the closest key
        private void GetClosestTargetableKey() 
        {
            float targetDist = float.MaxValue;
            GameObject targetKeyObj = null;
            foreach(DistanceReceiverPlane receiver in _distBroadcaster.ActiveReceiverPlanes)
            {
                GameObject candidateObj = receiver.gameObject;
                float candidateDist = receiver.GetDistance(_drumstickTip.transform.position);
                if (candidateObj.GetComponent<KeyInfo>() && candidateObj.GetComponent<Targetable>() &&
                    candidateDist < targetDist)
                {
                    targetKeyObj = candidateObj;
                    targetDist = candidateDist;
                }
            }
            _closestTargetableKey = targetKeyObj;
            _closestTargetableKeyDist = targetDist;
        }

        private void Reset()
        {
            _targetKeyObj = null;
            _beingClickedKeyObj = null;
            _closestTargetableKey = null;
            _targetHandle = null;
            _closestTargetableKeyDist = Mathf.Infinity;
        }

        public void OnTriggerDown(InputAction.CallbackContext context)
        {
            if (_inputType == InputType.Raycast && _targetKeyObj)
            {
                // We don't allow repeated clicking here
                _targetKeyObj?.GetComponent<Clickable>()?.Click();
                _targetKeyObj?.GetComponent<Clickable>()?.UnClick();
            }
            if (_targetHandle)
            {
                _targetHandle?.GetComponent<SideHandleAct>()?.StartFollow(this.gameObject, _inputType);
                _targetHandle?.GetComponent<Grabbable>()?.Grab();

                _grabbedHandle = _targetHandle;
                EnableInteraction(false);
            }
        }

        public void OnTriggerUp(InputAction.CallbackContext context)
        {
            if (_grabbedHandle)
            {
                _grabbedHandle.GetComponent<SideHandleAct>()?.StopFollow();
                _grabbedHandle.GetComponent<Grabbable>()?.UnGrab();

                // Also reset _targetHandle
                _grabbedHandle.GetComponent<Targetable>()?.TargetExit(); 
                _targetHandle = null;

                _grabbedHandle = null;               
                EnableInteraction(true);
            }
        }
    }
}
