// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    public class Raycaster : MonoBehaviour
    {
        public float Reach = 2.0f;
        
        public GameObject RaycastHitObj = null;
        
        [SerializeField] private LineRenderer _rayLineRenderer;
        
        private bool _hit;
        private RaycastHit _hitInfo;

        void Update()
        {
            UpdateRayVisual();
        }

        void FixedUpdate()
        {
            Raycast();
        }

        private void Raycast()
        {
            _hit = Physics.Raycast(
                _rayLineRenderer.gameObject.transform.position,
                _rayLineRenderer.gameObject.transform.forward,
                out _hitInfo, Reach
            );
            RaycastHitObj = (_hit && _hitInfo.transform.gameObject.GetComponent<Targetable>()) ? 
                _hitInfo.transform.gameObject : null;
        }

        private void UpdateRayVisual()
        {
            float drawRayLength = _hit ?
                Vector3.Distance(_rayLineRenderer.gameObject.transform.position, _hitInfo.point) :
                Reach;
            var linePositions = new Vector3[] {
                _rayLineRenderer.gameObject.transform.position,
                _rayLineRenderer.transform.position + drawRayLength * _rayLineRenderer.transform.forward
            };
            _rayLineRenderer.SetPositions(linePositions);
        }
    }
}
