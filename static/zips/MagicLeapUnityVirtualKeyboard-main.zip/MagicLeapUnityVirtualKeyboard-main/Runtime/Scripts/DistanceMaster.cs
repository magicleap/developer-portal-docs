﻿// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace MagicLeap.Keyboard
{
    /// <summary>
    /// A class that links DistanceReceivers & DistanceBroadcasters.
    /// </summary>
    public static class DistanceMaster
    {
        private static List<DistanceReceiver> receivers_;
        private static List<DistanceBroadcaster> broadcasters_;
        
        static DistanceMaster()
        {
            receivers_ = new List<DistanceReceiver>();
            broadcasters_ = new List<DistanceBroadcaster>();
        }

        public static void Tick()
        {
            foreach (DistanceBroadcaster broadcaster in broadcasters_)
            {
                broadcaster.ClearActiveReceivers();
            }
            foreach (DistanceReceiver receiver in receivers_)
            {
                receiver.ClearActiveBroadcasters();
            }
            foreach (DistanceBroadcaster broadcaster in broadcasters_)
            {
                foreach (DistanceReceiver receiver in receivers_)
                {
                    if (MeetsAllConditions(broadcaster, receiver))
                    {
                        broadcaster.AddActiveReceiver(receiver);
                        receiver.AddActiveBroadcaster(broadcaster);
                    }
                }
            }
        }

        public static void AddReceiver(DistanceReceiver receiver)
        {
            if (!receivers_.Contains(receiver))
            {
                receivers_.Add(receiver);
            }
        }

        public static void RemoveBroadcaster(DistanceBroadcaster broadcaster)
        {
            if (broadcasters_.Contains(broadcaster))
            {
                broadcasters_.Remove(broadcaster);
            }
        }

        public static void RemoveReceiver(DistanceReceiver receiver)
        {
            if (receivers_.Contains(receiver))
            {
                receivers_.Remove(receiver);
            }
        }

        public static void AddBroadcaster(DistanceBroadcaster broadcaster)
        {
            if (!broadcasters_.Contains(broadcaster))
            {
                broadcasters_.Add(broadcaster);
            }
        }

        public static bool MeetsAllConditions(DistanceBroadcaster broadcaster, DistanceReceiver receiver)
        {
            return broadcaster.enabled && broadcaster.gameObject.activeInHierarchy &&
                receiver.enabled && receiver.gameObject.activeInHierarchy &&
                receiver.GetDistance(broadcaster.transform.position) < receiver.AquireDistance;
        }
    }
}
