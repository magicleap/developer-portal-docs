// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace MagicLeap.Keyboard
{
    public class ControllerFollowTracking : MonoBehaviour
    {
        [FormerlySerializedAs("_totemInputWrapper")] [SerializeField] 
        private ControllerInputWrapper _controllerInputWrapper;

        private void Awake()
        {
            if (_controllerInputWrapper == null)
            {
                Debug.Log("_fillMeshAnimateMaterialFloat should not be null" +
                          "it needs to be hard-referenced in the Editor");
            }
        }

        private void Update()
        {
            if (_controllerInputWrapper != null)
            {
                transform.position = _controllerInputWrapper.GetTotemPos();
                transform.rotation = _controllerInputWrapper.GetTotemRot();
            }
        }
    }
}
