// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
namespace MagicLeap.Keyboard
{
    public class ControllerInputWrapper : MonoBehaviour
    {
        [SerializeField] private InteractionManager _interactionManager;

        private MagicLeapInputs _MLInputs;
        private MagicLeapInputs.ControllerActions _controllerActions;

        private Vector3 _totemPos;
        private Quaternion _totemRot;
        
        void Start()
        {
            _MLInputs = new MagicLeapInputs();
            _MLInputs.Enable();
            _controllerActions = new MagicLeapInputs.ControllerActions(_MLInputs);

            if (_interactionManager == null) 
                _interactionManager = GetComponent<InteractionManager>();
            if (_interactionManager != null)
            {
                _controllerActions.Trigger.started += _interactionManager.OnTriggerDown;
                _controllerActions.Trigger.canceled += _interactionManager.OnTriggerUp;
            }
        }
        
        void Update()
        {
            _totemPos = _controllerActions.Position.ReadValue<Vector3>();
            _totemRot = _controllerActions.Rotation.ReadValue<Quaternion>();
        }

        public Vector3 GetTotemPos() {return _totemPos;}
        public Quaternion GetTotemRot() {return _totemRot;}
    }
}
