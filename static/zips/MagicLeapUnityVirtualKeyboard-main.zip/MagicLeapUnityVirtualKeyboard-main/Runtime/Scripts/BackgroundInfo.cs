// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    public class BackgroundInfo : MonoBehaviour
    {
        public GameObject LeftHandleParent;
        public GameObject LeftHandle;
        public GameObject leftHandleHighlight;

        public GameObject RightHandleParent;
        public GameObject rightHandle;
        public GameObject rightHandleHighlight;

        [Tooltip("The large silhouette around the entire keyboard when the keyboard is grabbed")]
        public GameObject SilLarge;
        
        public GameObject Panel;
    }
}
