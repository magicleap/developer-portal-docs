// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    public class SideHandleAct : MonoBehaviour
    {
        [SerializeField] private float MoveLerpSpeed = 1.0f;
        [SerializeField] private float RotationLerpSpeed = 0.3f;

        [SerializeField] private GameObject _handleHighlight;
        [SerializeField] private GameObject _silLarge;
        
        private float _maxHeightDiff = 1.0f;
        private float _minHeightDiff = 0.0f;
        private float _maxKeyboardPitchG = 60.0f;
        private float _minKeyboardPitchG = 0.0f;
        private float _maxDisplayBarPitchG = 30.0f;
        private float _minDisplayBarPitchG = 0.0f;

        private Camera _camera;
        private GameObject _toFollow = null;
        private GameObject _keyboard = null;
        private GameObject _displayBar = null;

        private InputType _grabInputType = InputType.Raycast;

        private Vector3 _targetOffset;
        private Vector3 _targetPos;
        private float _targetPitchKeyboardG = 0.0f;
        private float _targetPitchDisplayBarG = 0.0f;

        public void SetKeyboardObj(GameObject obj)
        {
            _keyboard = obj;
        }

        public void SetDisplayBarObj(GameObject obj)
        {
            _displayBar = obj;
        }

        public void Highlight()
        {
            _handleHighlight.SetActive(true);
        }

        public void UnHighlight()
        {
            _handleHighlight.SetActive(false);
        }

        public void ShowSil()
        {
            _silLarge?.SetActive(true);
        }

        public void HideSil()
        {
            _silLarge?.SetActive(false);
        }

        public void StartFollow(GameObject toFollow, InputType inputType = InputType.Raycast)
        {
            _toFollow = toFollow; // setting this will start the Update process
            _grabInputType = inputType;
            _targetOffset = inputType == InputType.Raycast ?
                _toFollow.transform.InverseTransformVector(
                    transform.position - _toFollow.transform.position
                ) :
                transform.position - _toFollow.transform.position;
        }

        public void StopFollow()
        {
            _toFollow = null;
        }

        void Start()
        {
            _camera = Camera.main;
        }

        void Update()
        {
            if (_toFollow && _keyboard)
            {
                if (_camera)
                {
                    UpdatePitchTargets();
                    FollowCamera(_keyboard, _camera.gameObject, _targetPitchKeyboardG);
                    TiltDisplayBar(_displayBar, _targetPitchDisplayBarG - _targetPitchKeyboardG);
                }
                UpdatePosTarget(_targetOffset);
                GoToPos(_keyboard, _targetPos);
            }
        }

        private void UpdatePosTarget(Vector3 offset)
        {            
            Vector3 handlePos = _grabInputType == InputType.Raycast ? 
                _toFollow.transform.position + _toFollow.transform.TransformVector(offset) :
                _toFollow.transform.position + offset;
            _targetPos = handlePos - (transform.position - _keyboard.transform.position);
        }

        private void UpdatePitchTargets()
        {
            if (!_camera || !_keyboard) 
            {
                _targetPitchKeyboardG = 0.0f;
                _targetPitchDisplayBarG = 0.0f;
                return;
            }
            float heightDiff = Mathf.Clamp(_camera.transform.position.y - _keyboard.transform.position.y, 
                                           _minHeightDiff, _maxHeightDiff);
            _targetPitchKeyboardG = MapRanges(heightDiff, _minHeightDiff, _maxHeightDiff, 
                _minKeyboardPitchG, _maxKeyboardPitchG);
            _targetPitchDisplayBarG = MapRanges(heightDiff, _minHeightDiff, _maxHeightDiff,
                _minDisplayBarPitchG, _maxDisplayBarPitchG);          
        }

        private void GoToPos(GameObject obj, Vector3 targetPos, float epsilon = 0.001f)
        {
            Vector3 toTarget = targetPos - obj.transform.position;
            float dist = Vector3.Magnitude(toTarget);
            if (dist < epsilon)
            {
                return;
            }
            obj.transform.position += (toTarget * MoveLerpSpeed);
        }

        private void FollowCamera(GameObject obj, GameObject camera, float targetPitch, float epsilon = 0.1f)
        {
            Quaternion pitchRot = Quaternion.AngleAxis(targetPitch, Vector3.right);

            Vector3 toCamera = camera.transform.position - obj.transform.position;
            Vector3 toCameraHorizon = new Vector3(toCamera.x, 0.0f, toCamera.z);
            float distHorizon = Vector3.Magnitude(toCameraHorizon);
            toCameraHorizon = Vector3.Normalize(toCameraHorizon);
            Vector3 curFaceHorizon = Vector3.Normalize(new Vector3(-transform.forward.x, 0.0f, -transform.forward.z));
            Quaternion yawRot = distHorizon < 0.2f ? 
                                Quaternion.FromToRotation(Vector3.back, curFaceHorizon) :
                                Quaternion.FromToRotation(Vector3.back, toCameraHorizon);

            Quaternion targetOrient = yawRot * pitchRot;
            if (Quaternion.Angle(obj.transform.rotation, targetOrient) < epsilon)
            {
                return;
            }
            obj.transform.rotation = Quaternion.Lerp(obj.transform.rotation, targetOrient, RotationLerpSpeed);
        }

        private void TiltDisplayBar(GameObject obj, float targetPitchL)
        {
            obj.transform.localRotation = Quaternion.AngleAxis(targetPitchL, Vector3.right);
        }

        private float MapRanges(float curVal, float minFrom, float maxFrom,
                                float minTo, float maxTo)
        {
            curVal = Mathf.Clamp(curVal, minFrom, maxFrom);
            float percent = (curVal - minFrom) / (maxFrom - minFrom);
            return minTo + (maxTo - minTo) * percent;
        }
    }
}