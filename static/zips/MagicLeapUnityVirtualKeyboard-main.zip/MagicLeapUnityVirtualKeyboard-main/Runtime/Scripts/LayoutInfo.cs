// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    public class LayoutInfo : MonoBehaviour
    {
        public PageCode ThisPageCode;
        public Vector3 Extents;
        public GameObject KeysParent;
        public GameObject Background;
        public List<ShiftKeyBehavior> ShiftKeysBehavs = new List<ShiftKeyBehavior>();
    }
}