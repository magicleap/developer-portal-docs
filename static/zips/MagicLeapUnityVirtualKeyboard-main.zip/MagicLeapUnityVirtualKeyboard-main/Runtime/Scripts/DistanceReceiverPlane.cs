﻿// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 
namespace MagicLeap.Keyboard
{
    public class DistanceReceiverPlane : DistanceReceiver
    {
        // This value is lazily updated only when GetDistance or GetPos is called
        private Vector3 _boundedClosestP;

        public override float GetDistance(Vector3 p)
        {
            _boundedClosestP = Collider.ClosestPoint(p);
            return Vector3.Distance(p, _boundedClosestP);
        }

        public override Vector3 GetPos(Vector3 p)
        {
            _boundedClosestP = Collider.ClosestPoint(p);
            return _boundedClosestP;
        }
        
        private void Awake()
        {
            DistanceMaster.AddReceiver(this);
            Collider = GetComponent<Collider>();
        }


    }
}
