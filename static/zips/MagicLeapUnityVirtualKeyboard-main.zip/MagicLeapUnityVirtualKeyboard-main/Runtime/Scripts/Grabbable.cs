// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace MagicLeap.Keyboard
{
    public class Grabbable : MonoBehaviour
    {
        public UnityEvent OnGrab;
        public UnityEvent OnUnGrab;
        
        private bool _isBeingGrabbed;

        public void Grab()
        {
            if (!_isBeingGrabbed)
            {
                OnGrab.Invoke();
                _isBeingGrabbed = true;
            }
        }

        public void UnGrab()
        {
            if (_isBeingGrabbed)
            {
                OnUnGrab.Invoke();
                _isBeingGrabbed = false;
            }
        }
    }
}
