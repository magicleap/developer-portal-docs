// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

namespace MagicLeap.Keyboard
{
    public static class Util
    {
        public static void PrintDebugInfo(TMP_Text debugInfo, string text)
        {
            if (!debugInfo)
            {
                return;
            }

            debugInfo.text += text;

            if (debugInfo.text.Length > 500)
            {
                debugInfo.text = "";
            }
        }
    }
}