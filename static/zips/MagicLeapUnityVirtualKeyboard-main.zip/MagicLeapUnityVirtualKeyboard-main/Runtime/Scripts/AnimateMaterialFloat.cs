﻿// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using UnityEngine;
using System.Collections;
namespace MagicLeap.Keyboard
{
    /// <summary>
    /// Animates a target Material float property between two values 
    /// </summary>
    public class AnimateMaterialFloat : MonoBehaviour
    {
        [System.Serializable]
        public class Motion
        {
            public string MotionName;
            public float StartValue;
            public float EndValue;
            public float AnimationTime;
            public AnimationCurve MotionCurve = AnimationCurve.Linear(0f, 0f, 1f, 1f);
        }

        public int ActiveMotionInt = 0;

        [Tooltip("The renderer whose Material Color will be animated")]
        [SerializeField] private Renderer _targetRenderer = null;

        [Tooltip("The name of the target Material's Color property to be animated")]
        [SerializeField] private string _targetProperty = "_Activation";

        [SerializeField] private float _resetValue = 0.0f;

        [SerializeField] private Motion[] _motionCurves;

        [Tooltip("Animate from end value to start value")]
        [SerializeField] private bool _reverseDirection = false;

        [Tooltip("Start the animation on awake")]
        [SerializeField] private bool _playOnAwake = false;

        [Tooltip("How should the animation play?")]
        [SerializeField] private PlaybackType _playbackType = PlaybackType.Once;

        [SerializeField] private bool _printDebugInfo = false;

        private enum PlaybackType
        {
            Once, Loop, PingPong
        }

        private float _elapsedTime = 0.0f;
        private float _animationPercentComplete = 0f;
        private bool _playForward = true;
        private int _lastMotionPlayed;

        private void Awake()
        {
            if (_playOnAwake && _motionCurves.Length > 0)
            {
               Play(0);
            }
        }

        private void OnDisable()
        {
            StopAllCoroutines();
            Reset(ActiveMotionInt);
        }

        /// <summary>
        /// Control the animation manually. Set the % through the animation.
        /// </summary>
        /// <param name="percent"></param>
        public void AnimatePercent(float percent)
        {
            if (gameObject.activeInHierarchy)
            {
                float activeFloatValue = Mathf.Lerp(
                    _motionCurves[ActiveMotionInt].StartValue,
                    _motionCurves[ActiveMotionInt].EndValue,
                    _motionCurves[ActiveMotionInt].MotionCurve.Evaluate(percent));
                _targetRenderer.material.SetFloat(_targetProperty, activeFloatValue);
            }
        }

        public void PlayForward()
        {
           PlayForward(ActiveMotionInt);
        }

        public void PlayForward(int motionInt)
        {
            if (gameObject.activeInHierarchy)
            {
                if (_printDebugInfo)
                {
                    Debug.Log(gameObject.name + "PlayForward: " + motionInt);
                }
                _playForward = true;

                Motion currentMotion = _motionCurves[motionInt];
                StopAllCoroutines();
                StartCoroutine(LerpFloat(
                    currentMotion.StartValue,
                    currentMotion.EndValue,
                    currentMotion.MotionCurve,
                    currentMotion.AnimationTime));
                _lastMotionPlayed = ActiveMotionInt;
            }
        }

        public void PlayReverse()
        {
            PlayReverse(ActiveMotionInt);
        }

        public void PlayReverse(int motionInt)
        {
            if (gameObject.activeInHierarchy)
            {
                if (_printDebugInfo)
                {
                    Debug.Log(gameObject.name + "PlayReverse: " + motionInt);
                }
                _playForward = false;
                Motion currentMotion = _motionCurves[motionInt];
                StopAllCoroutines();
                StartCoroutine(LerpFloat(
                    currentMotion.EndValue,
                    currentMotion.StartValue,
                    currentMotion.MotionCurve,
                    currentMotion.AnimationTime));
                _lastMotionPlayed = ActiveMotionInt;
            }
        }

        public void PlayReset()
        {
            PlayReset(ActiveMotionInt);
        }

        public void PlayReset(int motionInt)
        {
            if (gameObject.activeInHierarchy)
            {
                if (_printDebugInfo)
                {
                    Debug.Log(gameObject.name + "PlayReverse: " + motionInt);
                }
                _playForward = false;
                Motion currentMotion = _motionCurves[motionInt];
                StopAllCoroutines();
                StartCoroutine(LerpFloat(
                    currentMotion.EndValue, 
                    currentMotion.StartValue, 
                    currentMotion.MotionCurve, 
                    0.01f));
                _lastMotionPlayed = ActiveMotionInt;
            }
        }
        
        public void Play(int motionInt)
        {
            if (gameObject.activeInHierarchy)
            {
                _lastMotionPlayed = motionInt;
                if (_reverseDirection)
                {
                    PlayReverse();
                }
                else
                {
                    PlayForward();
                }
            }
        }

        public void Reset(int motionInt)
        {
            _targetRenderer.material.SetFloat(_targetProperty, _resetValue);
            _elapsedTime = 0f;
            _animationPercentComplete = 0f;
        }

        public void ReplayLast()
        {
            if (gameObject.activeInHierarchy)
            {
                Play(_lastMotionPlayed);
            }
        }

        private IEnumerator LerpFloat(float startValue, float endValue, AnimationCurve animCurve, float animationTime)
        {
            _elapsedTime = 0.0f;
            while (_elapsedTime < 1.0f)
            {
                _elapsedTime += (Time.deltaTime / animationTime);
                _animationPercentComplete = Mathf.Clamp((_elapsedTime / 1), 0.0f, 1.0f);
                if (_playForward)
                {
                    float activeFloatValue = Mathf.Lerp(startValue, endValue, animCurve.Evaluate(_elapsedTime));
                    _targetRenderer.material.SetFloat(_targetProperty, activeFloatValue);
                }
                else
                {
                    float activeFloatValue = Mathf.Lerp(endValue, startValue, animCurve.Evaluate(_elapsedTime));
                    _targetRenderer.material.SetFloat(_targetProperty, activeFloatValue);
                }
                yield return null;
            }
            if (_playbackType == PlaybackType.Loop)
            {
                ReplayLast();
            }
            if (_playbackType == PlaybackType.PingPong)
            {
                _playForward = !_playForward;
                ReplayLast();
            }
        }
    }
}
