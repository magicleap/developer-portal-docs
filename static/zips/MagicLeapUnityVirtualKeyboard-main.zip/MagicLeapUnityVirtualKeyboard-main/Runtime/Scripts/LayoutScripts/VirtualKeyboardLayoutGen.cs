// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using TMPro;
using System.IO;

namespace MagicLeap.Keyboard
{
    using PageID = System.UInt32;

    public class VirtualKeyboardLayoutGen : MonoBehaviour
    {
        public static readonly string KEYBOARD_KEY_NAME_PREFIX = "ML_VKB_btn-";
        public static readonly float DEFAULT_KEYBOARD_THICKNESS = 0.03f;

        // Background scale and position
        public static readonly float BACKGROUND_Z_OFFSET = 0.005f;
        public static readonly float BACKGROUND_EDGE_WIDTH = 0.006f;
        public static readonly float HANDLE_WIDTH = 0.02f;
        public static readonly float BACKGROUND_SIL_WIDTH = 0.003f;

        public Code Locale = Code.kEn_US_Unity;
        public bool OverwriteStoredPrefab = false;

        [SerializeField] private GameObject _backgroundPrefab;
        [SerializeField] private GameObject _kCharacterPrefab;
        [SerializeField] private GameObject _kTabPrefab;
        [SerializeField] private GameObject _kShiftPrefab;
        [SerializeField] private GameObject _kPageNumericSymbolsPrefab;
        [SerializeField] private GameObject _kBackspacePrefab;
        [SerializeField] private GameObject _kEnterPrefab;
        [SerializeField] private GameObject _kSpacebarPrefab;
        [SerializeField] private GameObject _kCharacterSpecialPrefab;

        [SerializeField] private GameObject _layoutsParent;

        [SerializeField] private Material _buttonFillLightMat = null;
        [SerializeField] private Material _buttonFillMediumMat = null;
        [SerializeField] private Material _buttonFillDarkMat = null;

        [SerializeField, Tooltip("The Eng prefab that will be overwritten if OverwriteStoredPrefab == true")]
        private GameObject _engLayoutsPrefab;

        [SerializeField, Tooltip("The Japan prefab that will be overwritten if OverwriteStoredPrefab == true")]
        private GameObject _japanLayoutsPrefab;

        private VirtualKeyboardBuilder _virtualKeyboardBuilder;
        private Dictionary<KeyType, GameObject> _keyTypeToPrefabMap = new Dictionary<KeyType, GameObject>();
        private Dictionary<Code, GameObject> _languageToPrefabMap = new Dictionary<Code, GameObject>();
        private GameObject _backgroundParentObj = null;
        private GameObject _keysParentObj;
        private GameObject _keysAndBackgroundParentObj;
        private LayoutInfo _layoutInfo;
        private LayoutType _layoutType = LayoutType.kFull; // currently only support this one

        public bool Init()
        {
            _virtualKeyboardBuilder = GetComponent<VirtualKeyboardBuilder>();
            if (!_virtualKeyboardBuilder)
            {
                Debug.LogError("Cannot find VirtualKeyboardBuilder! Abort!");
                return false;
            }
            bool success = _virtualKeyboardBuilder.Init();
            if (!success)
            {
                Debug.LogError("_virtualKeyboardBuilder init failed!");
                return false;
            }
            CreateKeyTypeToPrefabMap();
            CreateLanguageToPrefabMap();
            return true;
        }

        public bool GenLanguageLayouts(Code locale)
        {
            bool success = Init();
            if (success)
            {
                Debug.Log("VirtualKeyboard init() successfully finished");
            }
            else
            {
                Debug.LogError("VirtualKeyboard init() failed");
                return false;
            }
            LocaleDesc localeDesc = GetLocaleDesc(locale);
            ClearLayouts(_layoutsParent);
            foreach (KeyValuePair<PageID, PageLayoutDesc> pair in localeDesc.LayoutMap)
            {
                _keysAndBackgroundParentObj = new GameObject("layout__" + locale + "__" + (PageCode)pair.Key);
                _keysAndBackgroundParentObj.transform.parent = _layoutsParent.transform;
                _keysAndBackgroundParentObj.transform.localPosition = Vector3.zero;
                _keysAndBackgroundParentObj.transform.localRotation = Quaternion.identity;
                _keysAndBackgroundParentObj.transform.localScale = Vector3.one;
                GenOneLayout(locale, (PageCode)pair.Key);
            }

            // Choose which one to set active (the first layout to load when using this language)
            PageID defaultPage = GetPageLayoutProperties(locale, _layoutType).DefaultPage;
            for (int i=0; i<_layoutsParent.transform.childCount; i++)
            {
                GameObject layoutObj = _layoutsParent.transform.GetChild(i).gameObject;
                LayoutInfo layoutInfo = layoutObj.GetComponent<LayoutInfo>();
                if (!layoutInfo)
                {
                    Debug.LogError("Missing LayoutInfo!");
                    continue;
                }

                PageCode curPageCode= layoutInfo.ThisPageCode;
                if (defaultPage != (PageID) curPageCode)
                {
                    _layoutsParent.transform.GetChild(i).gameObject.SetActive(false);
                }
            }
#if UNITY_EDITOR
            if (OverwriteStoredPrefab)
            {
                OverwritePrefab(locale);
            }
#endif
            return true;
        }

        private void CreateKeyTypeToPrefabMap()
        {
            _keyTypeToPrefabMap.Clear();
            _keyTypeToPrefabMap.Add(KeyType.kCharacter, _kCharacterPrefab);
            _keyTypeToPrefabMap.Add(KeyType.kTab, _kTabPrefab);
            _keyTypeToPrefabMap.Add(KeyType.kShift, _kShiftPrefab);
            _keyTypeToPrefabMap.Add(KeyType.kPageNumericSymbols, _kPageNumericSymbolsPrefab);
            _keyTypeToPrefabMap.Add(KeyType.kBackspace, _kBackspacePrefab);
            _keyTypeToPrefabMap.Add(KeyType.kEnter, _kEnterPrefab);
            _keyTypeToPrefabMap.Add(KeyType.kSpacebar, _kSpacebarPrefab);
            _keyTypeToPrefabMap.Add(KeyType.kCharacterSpecial, _kCharacterSpecialPrefab);
            
            // Below are temp hacks until we have more language support
            _keyTypeToPrefabMap.Add(KeyType.kAutoAlternateSelector, _kCharacterPrefab);
            _keyTypeToPrefabMap.Add(KeyType.kAltCharToggle, _kCharacterPrefab);
        }

        private void CreateLanguageToPrefabMap()
        {
            _languageToPrefabMap.Clear();
            _languageToPrefabMap.Add(Code.kEn_US_Unity, _engLayoutsPrefab);
            _languageToPrefabMap.Add(Code.kJp_JP_Unity, _japanLayoutsPrefab);
        }

        private PageLayoutDesc GetPageLayoutDesc(Code locale, PageID pageID)
        {
            if (!_virtualKeyboardBuilder.GetLocaleMap().ContainsKey(locale))
            {
                Debug.LogError("Could not find map entry for locale: " + locale);
                return null;
            }
            LocaleDesc localeDesc = _virtualKeyboardBuilder.GetLocaleMap()[locale];
            if (!localeDesc.LayoutMap.ContainsKey(pageID))
            {
                Debug.LogError("Could not find page in that locale, page: " + (PageCode)pageID);
                return null;
            }
            return localeDesc.LayoutMap[pageID];
        }

        private LocaleDesc GetLocaleDesc(Code locale)
        {
            if (!_virtualKeyboardBuilder.GetLocaleMap().ContainsKey(locale))
            {
                Debug.LogError("Could not find map entry for locale: " + locale);
                return null;
            }
            return _virtualKeyboardBuilder.GetLocaleMap()[locale];
        }

        private PageLayoutProperties GetPageLayoutProperties(Code locale, LayoutType layoutType)
        {
            if (!_virtualKeyboardBuilder.GetLocaleMap().ContainsKey(locale))
            {
                Debug.LogError("Could not find map entry for locale: " + locale);
                return null;
            }       
            LocaleDesc localeDesc = _virtualKeyboardBuilder.GetLocaleMap()[locale];
            if (!localeDesc.PropertyMap.ContainsKey(layoutType)) 
            {
                Debug.LogError("Could not find map entry for layoutType: " + layoutType);
                return null;
            }
            return localeDesc.PropertyMap[layoutType];
        }

        private bool GenOneLayout(Code locale, PageCode pageCode)
        {
            PageLayoutDesc pageLayoutDesc = GetPageLayoutDesc(locale, (PageID)pageCode);
            if (pageLayoutDesc == null)
            {
                Debug.LogError("Layout description missing for given page: locale: " +
                               locale + " page: " + pageCode);
                return false;
            }
            
            Vector3 extents = GetKeyboardKeysExtents(pageLayoutDesc);
            CreateInfo(pageCode, extents);
            CreateKeys(pageLayoutDesc, new Vector2(-extents.x * 0.5f, extents.y * 0.5f));
            CreateBackground(extents);

            return true;
        }

        private Vector3 GetKeyboardKeysExtents(PageLayoutDesc pageLayoutDesc)
        {
            // Currently no key spans more than one row, so we can calculate height like this
            float keyGap = pageLayoutDesc.KeyGap;
            Vector2 defKeySize = new Vector2(pageLayoutDesc.DefaultKeySize.x, pageLayoutDesc.DefaultKeySize.y);
            int rowCount = pageLayoutDesc.KeyLayoutRows.Count;
            float height = (rowCount + 1) * keyGap + rowCount * defKeySize.y;

            float maxRowWidth = 0.0f;
            for (int i = 0; i < rowCount; i++)
            {
                float rowWidth = 0.0f;
                for (int j = 0; j < pageLayoutDesc.KeyLayoutRows[i].Count; j++)
                {
                    float widthWeight = pageLayoutDesc.KeyLayoutRows[i][j].KeyWidthWeight;
                    float gapOnLeft = pageLayoutDesc.KeyLayoutRows[i][j].GapOnLeft;
                    rowWidth += (widthWeight * defKeySize.x + pageLayoutDesc.KeyGap + gapOnLeft +
                                 Mathf.Ceil(widthWeight - 1.0f) * pageLayoutDesc.KeyGap);
                }

                if (rowWidth > maxRowWidth)
                {
                    maxRowWidth = rowWidth;
                }
            }
            return new Vector3(maxRowWidth, height, DEFAULT_KEYBOARD_THICKNESS);
        }

        private void ClearLayouts(GameObject layoutsParent)
        {
            GameObject origParent = layoutsParent.transform.parent ?
                layoutsParent.transform.parent.gameObject : null;
            DestroyImmediate(_layoutsParent);
            _layoutsParent = new GameObject("Layouts__" + Locale);
            if (origParent)
            {
                _layoutsParent.transform.SetParent(origParent.transform);
            }
            _layoutsParent.transform.localPosition = Vector3.zero;
            _layoutsParent.transform.localRotation= Quaternion.identity;
            _layoutsParent.transform.localScale = Vector3.one;
        }

        private GameObject CreateKey(KeyLayoutDesc origKeyLayoutDesc, GameObject parentNode)
        {
            KeyDesc origKeyDesc = origKeyLayoutDesc.ThisKeyDesc;

            string label = origKeyDesc.DefaultLabeledKey.Label.ToStr();

            // Instantiate the key
            GameObject prefabToUse = _keyTypeToPrefabMap.ContainsKey(origKeyDesc.KeyType) ?
                _keyTypeToPrefabMap[origKeyDesc.KeyType] : _kCharacterPrefab;
            GameObject keyButton = GameObject.Instantiate(
                prefabToUse,
                parentNode.transform,
                false
            );
            keyButton.transform.localPosition = Vector3.zero;
            keyButton.transform.localRotation = Quaternion.identity;
            keyButton.transform.localScale = Vector3.one;
            keyButton.name = KEYBOARD_KEY_NAME_PREFIX + label;
            return keyButton;
        }

        private void PositionKey(GameObject key, float keyWidth, float keyHeight, 
                                 Vector2 startCoords, float gapOnLeft = 0f)
        {
            float xOffset = keyWidth * 0.5f;
            float yOffset = keyHeight * 0.5f;
            key.transform.localPosition = new Vector3(
                startCoords.x + xOffset + gapOnLeft, startCoords.y - yOffset, key.transform.localPosition.z);
        }

        private void ConfigKey(GameObject keyObj, KeyLayoutDesc origKeyLayoutDesc)
        {
            KeyInfo keyInfo= keyObj.GetComponent<KeyInfo>();
            if (!keyInfo)
            {
                Debug.LogError("Could not find KeyInfo script on key prefab, aborting!");
                return;
            }

            keyInfo.KeyType = origKeyLayoutDesc.ThisKeyDesc.KeyType;
            switch (keyInfo.KeyType)
            {
                case KeyType.kCharacter:
                case KeyType.kCharacterSpecial:
                    if (keyInfo.KeyTextMesh == null)
                    {
                        Debug.LogError("Missing KeyTextMesh on KeyInfo, aborting!");
                        return;
                    }
                    string text = origKeyLayoutDesc.ThisKeyDesc.DefaultLabeledKey.Label.ToStr();
                    // Set the label on the new key
                    keyInfo.KeyTextMesh.text = text;
                    // Set the content to type when key click handler is invoked
                    keyInfo.TextToType = text;
                    break;
                case KeyType.kSpacebar:
                    keyInfo.TextToType = " ";
                    break;
                case KeyType.kTab:
                    keyInfo.TextToType = "    ";
                    break;
                case KeyType.kShift:
                    ShiftKeyBehavior behavScript = keyObj.GetComponent<ShiftKeyBehavior>();
                    if(behavScript) 
                    {
                        _layoutInfo.ShiftKeysBehavs.Add(behavScript);
                        behavScript.SwitchStatus(
                            _layoutInfo.ThisPageCode == PageCode.kUpperLetters ? 
                            ShiftKeyState.OnTemp : ShiftKeyState.Off
                        );
                    }
                    break;
                default:
                    break;
            }

            // Key fill style through materials
            if (origKeyLayoutDesc.KeyButtonStyle != KeyButtonStyle.kDefault)
            {
                Renderer fillObj = keyInfo.KeyFillRenderer;
                if (fillObj == null)
                {
                    Debug.LogError("Missing KeyFillRenderer on KeyInfo, aborting!");
                    return;
                }

                Material fillMatToLoad = _buttonFillLightMat;
                switch (origKeyLayoutDesc.KeyButtonStyle)
                {
                    case KeyButtonStyle.kLight:
                        fillMatToLoad = _buttonFillLightMat;
                        break;
                    case KeyButtonStyle.kMedium:
                        fillMatToLoad = _buttonFillMediumMat;
                        break;
                    case KeyButtonStyle.kDark:
                        fillMatToLoad = _buttonFillDarkMat;
                        break;
                    default:
                        break;
                }

                fillObj.GetComponent<Renderer>().material = fillMatToLoad;
            }
        }

        private void CreateKeys(PageLayoutDesc pageLayoutDesc, Vector2 topLeftCorner)
        {
            _keysParentObj = new GameObject("Keys");
            _keysParentObj.transform.SetParent(_keysAndBackgroundParentObj.transform);
            _keysParentObj.transform.localPosition = Vector3.zero;
            _keysParentObj.transform.localScale = Vector3.one;
            _keysParentObj.transform.localRotation = Quaternion.identity;

            _layoutInfo.KeysParent = _keysParentObj;

            float nextKeyStartCoordsX = topLeftCorner.x + pageLayoutDesc.KeyGap;
            float nextKeyStartCoordsY = topLeftCorner.y - pageLayoutDesc.KeyGap;

            float rowSpacing = pageLayoutDesc.DefaultKeySize.y + pageLayoutDesc.KeyGap;
            int rowCount = pageLayoutDesc.KeyLayoutRows.Count;

            for (int i = 0; i < rowCount; i++)
            {
                int rowSize = pageLayoutDesc.KeyLayoutRows[i].Count;
                for (int j = 0; j < rowSize; j++)
                {
                    KeyLayoutDesc keyLayoutDesc = pageLayoutDesc.KeyLayoutRows[i][j];
                    float keyWidth = keyLayoutDesc.KeyWidthWeight * pageLayoutDesc.DefaultKeySize.x +
                                     Mathf.Ceil(keyLayoutDesc.KeyWidthWeight - 1.0f) * pageLayoutDesc.KeyGap;
                    GameObject keyButton = CreateKey(keyLayoutDesc, _keysParentObj);
                    if (keyButton)
                    {
                        PositionKey(
                            keyButton, 
                            keyWidth, pageLayoutDesc.DefaultKeySize.y,  
                            new Vector2(nextKeyStartCoordsX, nextKeyStartCoordsY),
                            keyLayoutDesc.GapOnLeft
                        );
                        ConfigKey(keyButton, keyLayoutDesc);
                    }
                    nextKeyStartCoordsX += (keyWidth + pageLayoutDesc.KeyGap + keyLayoutDesc.GapOnLeft);
                }
                nextKeyStartCoordsX = topLeftCorner.x + pageLayoutDesc.KeyGap;
                nextKeyStartCoordsY -= rowSpacing;
            }
        }

#if UNITY_EDITOR
        private void OverwritePrefab(Code locale)
        {
            if (!_languageToPrefabMap.ContainsKey(locale))
            {
                Debug.LogError("Could not find prefab for language of " + locale +
                               "when trying to overwrite it, aborting!");
                return;
            }

            var path = AssetDatabase.GetAssetPath(_languageToPrefabMap[locale]);
            Debug.Log("Path to overwrite prefab is: " + path);

            bool success = false;
            PrefabUtility.SaveAsPrefabAsset(_layoutsParent, path, out success);
            Debug.Log("saving layouts prefab success: " + success);
        }
#endif

        private void CreateBackground(Vector3 extents)
        {
            if (_backgroundPrefab == null)
            {
                return;
            }

            _backgroundParentObj = GameObject.Instantiate(_backgroundPrefab, _keysAndBackgroundParentObj.transform);
            _backgroundParentObj.name = "Background";
            _backgroundParentObj.transform.localScale = Vector3.one;
            _backgroundParentObj.transform.localPosition = Vector3.zero;
            _backgroundParentObj.transform.localRotation = Quaternion.identity;

            _layoutInfo.Background = _backgroundParentObj;

            BackgroundInfo backgroundInfo = _backgroundParentObj.GetComponent<BackgroundInfo>();
            if (backgroundInfo == null)
            {
                Debug.LogError("Missing BackgroundInfo script on created Background prefab instance, aborting!");
                return;
            }

            GameObject leftHandleParent = backgroundInfo.LeftHandleParent;
            GameObject leftHandle = backgroundInfo.LeftHandle;
            GameObject leftHandleHighlight = backgroundInfo.leftHandleHighlight;

            GameObject rightHandleParent = backgroundInfo.RightHandleParent;
            GameObject rightHandle = backgroundInfo.rightHandle;
            GameObject rightHandleHighlight = backgroundInfo.rightHandleHighlight;

            GameObject silLarge = backgroundInfo.SilLarge;
            GameObject panel = backgroundInfo.Panel;

            if (!(leftHandleParent && leftHandle && leftHandleHighlight && 
                  rightHandleParent && rightHandle && rightHandleHighlight &&
                  silLarge && panel))
            {
                Debug.LogError("One or more components in the keyboard background cannot be found, " +
                               "aborting on creating background!");
                return;
            }

            leftHandleParent.transform.localPosition = new Vector3(
                -extents.x * 0.5f - HANDLE_WIDTH * 0.5f - BACKGROUND_EDGE_WIDTH,
                0.0f,
                BACKGROUND_Z_OFFSET
            );
            leftHandleParent.transform.localScale = new Vector3(
                HANDLE_WIDTH, extents.y + 2.0f * BACKGROUND_EDGE_WIDTH, 1.0f
            );
            leftHandle.transform.localPosition = Vector3.zero;
            leftHandle.transform.localScale = Vector3.one;
            leftHandleHighlight.transform.localPosition = Vector3.zero;
            leftHandleHighlight.transform.localScale = Vector3.one;

            rightHandleParent.transform.localPosition = new Vector3(
                extents.x * 0.5f + HANDLE_WIDTH * 0.5f + BACKGROUND_EDGE_WIDTH,
                0.0f,
                BACKGROUND_Z_OFFSET
            );
            rightHandleParent.transform.localScale = new Vector3(
                HANDLE_WIDTH, extents.y + 2.0f * BACKGROUND_EDGE_WIDTH, 1.0f
            );
            rightHandle.transform.localPosition = Vector3.zero;
            rightHandle.transform.localScale = Vector3.one;
            rightHandleHighlight.transform.localPosition = Vector3.zero;
            rightHandleHighlight.transform.localScale = Vector3.one;

            panel.transform.localPosition = new Vector3(
                0.0f, 0.0f, BACKGROUND_Z_OFFSET
            );
            panel.transform.localScale = new Vector3(
                extents.x + 2.0f * BACKGROUND_EDGE_WIDTH,
                extents.y + 2.0f * BACKGROUND_EDGE_WIDTH,
                1.0f
            );

            silLarge.transform.localPosition = new Vector3(
                0.0f, 0.0f, BACKGROUND_Z_OFFSET
            );
            silLarge.transform.localScale = new Vector3(
                extents.x + 2.0f * (BACKGROUND_EDGE_WIDTH + BACKGROUND_SIL_WIDTH) + 2.0f * HANDLE_WIDTH,
                extents.y + 2.0f * (BACKGROUND_EDGE_WIDTH + BACKGROUND_SIL_WIDTH),
                1.0f
            );
        }

        private void CreateInfo(PageCode pageCode, Vector3 extents)
        {
            _layoutInfo = _keysAndBackgroundParentObj.AddComponent<LayoutInfo>();
            _layoutInfo.ThisPageCode = pageCode;
            _layoutInfo.Extents = extents;
            _layoutInfo.ShiftKeysBehavs.Clear();
        }
    }
}