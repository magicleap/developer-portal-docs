// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    [System.Serializable]
    public class AlternateKey_JSON
    {
        public string Key;
    }

    [System.Serializable]
    public class AlternateKeyGroup_JSON
    {
        public string AlternateKeyGroupID;
        public AlternateKey_JSON[] AlternateKeys;
    }

    [System.Serializable]
    public class AlternateKeySelectorConfig_JSON
    {
        public string AlternateKeySelectorID;
        public AlternateKeyGroup_JSON[] AlternateKeyGroups;
    }

    ////////// JSON for layout configs ////////////////////////////////
    [System.Serializable]
    public class Key_JSON
    {
        public string KeyTypeID;
        public string DefaultChar;
        public string AlternateKeySelectorID;
        public string WidthWeight; // meant to be float
        public string GapOnLeft; // meant to be float
        public string KeyButtonStyle;
    }

    [System.Serializable]
    public class KeyRow_JSON
    {
        public Key_JSON[] KeyRow;
    }

    [System.Serializable]
    public class PageLayout_JSON
    {
        public string PageLayoutID;
        public KeyRow_JSON[] KeyRows;
        public float DefaultKeySizeX;
        public float DefaultKeySizeY;
        public float DefaultKeySizeZ;
        public float KeyboardWidth;
        public float KeyGap;
    }

    [System.Serializable]
    public class KeyPage_JSON
    {
        public string KeyTypeID;
        public string PageLayoutID;
    }

    [System.Serializable]
    public class KeyboardPageSetProperty_JSON
    {
        public string PageLayoutID;
        public KeyPage_JSON[] KeyPage;
    }

    [System.Serializable]
    public class KeyboardPageSet_JSON
    {
        public string KeyboardPageSetID;
        public KeyboardPageSetProperty_JSON[] KeyboardPageSetProperties;
        public string PageLayoutID;
    }

    [System.Serializable]
    public class Label_JSON
    {
        public string Label;
    }

    [System.Serializable]
    public class SwappableLabelKey_JSON
    {
        public string KeyTypeID;
        public string Char;
        public Label_JSON[] Labels;
    }

    [System.Serializable]
    public class LayoutConfig_JSON
    {
        public string LanguageID;
        public PageLayout_JSON[] PageLayouts;
        public KeyboardPageSet_JSON[] KeyboardPageSets;
        public SwappableLabelKey_JSON[] SwappableLabelKeys;
    }

    public class JSONParser
    {
        public AlternateKeySelectorConfig_JSON ParseAlternateKeySelectorConfig(TextAsset textAsset)
        {
            return JsonUtility.FromJson<AlternateKeySelectorConfig_JSON>(textAsset.text);
        }

        public LayoutConfig_JSON ParsePageLayout(TextAsset textAsset)
        {
            return JsonUtility.FromJson<LayoutConfig_JSON>(textAsset.text);
        }
    }
}
