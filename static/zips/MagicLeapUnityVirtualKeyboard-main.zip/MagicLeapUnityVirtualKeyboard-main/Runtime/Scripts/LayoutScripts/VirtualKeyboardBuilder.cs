// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.Linq;
using System.IO;
using TMPro;

namespace MagicLeap.Keyboard
{
    using KeyTypePageLinkVec = System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<KeyType, PageLink>>;
    using PageID = System.UInt32;

    public struct KeyLayoutDesc
    {
        public KeyDesc ThisKeyDesc;
        public float KeyWidthWeight;
        public float GapOnLeft;
        public KeyButtonStyle KeyButtonStyle;

        public KeyLayoutDesc(KeyDesc a_keyDesc, float a_keyWidthWeight, float a_gapOnLeft = 0f, 
                             KeyButtonStyle style = KeyButtonStyle.kDefault)
        {
            ThisKeyDesc = a_keyDesc;
            KeyWidthWeight = a_keyWidthWeight;
            GapOnLeft = a_gapOnLeft;
            KeyButtonStyle = style;
        }

        public string ToStr()
        {
            return "KeyLayoutDesc {keyDesc: " + ThisKeyDesc.ToStr() + "; keyWidthWeight: " + KeyWidthWeight + 
                   "; gapOnLeft: " + GapOnLeft + "} ";
        }
    }

    public class PageLayoutDesc
    {
        public List<List<KeyLayoutDesc>> KeyLayoutRows;
        public Vector3 DefaultKeySize;
        public float KeyboardWidth;
        public float KeyGap;

        public PageLayoutDesc()
        {
            KeyLayoutRows = new List<List<KeyLayoutDesc>>();
            DefaultKeySize = new Vector3();
            KeyboardWidth = 0.0f;
            KeyGap = 0.0f;
        }

        public string ToStr()
        {
            string result = "PageLayoutDesc {keyLayoutRows: ";
            for (int i = 0; i < KeyLayoutRows.Count; i++)
            {
                string line = "Row No. " + i + ": ";
                for (int j = 0; j < KeyLayoutRows[i].Count; j++)
                {
                    line += (KeyLayoutRows[i][j].ToStr() + ", ");
                }
                result += (line + ";\n");
            }
            result += ("; defaultKeySizeX: " + DefaultKeySize.x +
                       "; defaultKeySizeY: " + DefaultKeySize.y +
                       "; defaultKeySizeZ: " + DefaultKeySize.z +
                       "; keyboardWidth: " + KeyboardWidth +
                       "; keyGap: " + KeyGap + "}\n");
            return result;
        }
    }

    public enum LinkButton
    {
        kNone,
        kCenterLeft,
        kCenterRight,
        kLowerLeft,
        kLowerRight,
        kUpperLeft,
        kUpperRight
    }

    // This struct could hold more information in the future
    public struct PageLink
    {
        public readonly PageID ThisPageID;

        public PageLink(PageID a_pageID)
        {
            ThisPageID = a_pageID;
        }

        public string ToStr()
        {
            string result = "PageLink {pageID: " + ThisPageID + "} ";
            return result;
        }
    }

    public class PageLayoutProperties
    {
        public SortedDictionary<PageID, KeyTypePageLinkVec> PageLinkMap;
        public PageID DefaultPage;

        public PageLayoutProperties()
        {
            PageLinkMap = new SortedDictionary<PageID, KeyTypePageLinkVec>();
            DefaultPage = new PageID();
        }

        public string ToStr()
        {
            string result = "defaultPage: " + DefaultPage + "\n";
            foreach (KeyValuePair<PageID, KeyTypePageLinkVec> pair in PageLinkMap)
            {
                result += ("key(PageID): " + pair.Key + "\n");
                result += ("value(List<KeyValuePair<KeyType, PageLink>>: ");
                foreach (KeyValuePair<KeyType, PageLink> page in pair.Value)
                {
                    result += ("{KeyType: " + page.Key + "; " + "PageLink: " + page.Value.ToStr() + "}, ");
                }
                result += "\n";
            }
            return result;
        }
    }

    public class LocaleDesc
    {
        public SortedDictionary<PageID, PageLayoutDesc> LayoutMap;
        public SortedDictionary<LayoutType, PageLayoutProperties> PropertyMap;
        public SortedDictionary<KeyType, MultiLabeledKey> AdditionalKeyLabels;
        public Dictionary<Char32_t, Char32_t> NextAlternateKeyMap;

        public LocaleDesc()
        {
            LayoutMap = new SortedDictionary<PageID, PageLayoutDesc>();
            PropertyMap = new SortedDictionary<LayoutType, PageLayoutProperties>();
            AdditionalKeyLabels = new SortedDictionary<KeyType, MultiLabeledKey>();
            NextAlternateKeyMap = new Dictionary<Char32_t, Char32_t>();
        }

        public string ToStr()
        {
            // Print layoutMap
            string result = "LocaleDesc {layoutMap:\n";
            foreach (KeyValuePair<PageID, PageLayoutDesc> pair in LayoutMap)
            {
                result += ("key(PageID): " + pair.Key + ";\n");
                result += ("value(PageLayoutDesc): " + pair.Value.ToStr() + ", ");
            }

            // Print propertyMap
            result += "}\n\n{propertyMap:\n";
            foreach (KeyValuePair<LayoutType, PageLayoutProperties> pair in PropertyMap)
            {
                result += ("key(LayoutType): " + pair.Key + ";\n");
                result += ("value(PageLayoutProperties): " + pair.Value.ToStr() + ";\n");
            }

            // Print additionalKeyLabels
            result += "}\n\n{additionalKeyLabels:\n";
            foreach (KeyValuePair<KeyType, MultiLabeledKey> pair in AdditionalKeyLabels)
            {
                result += ("key(KeyType): " + pair.Key + ";\n");
                result += ("value(MultiLabeledKey): " + pair.Value.ToStr() + ";\n");
            }

            // Print nextAlternateKeyMap
            result += "}\n\n{nextAlternateKeyMap:\n";
            foreach (KeyValuePair<Char32_t, Char32_t> pair in NextAlternateKeyMap)
            {
                result += ("key(char): " + pair.Key.ToStr() + "; ");
                result += ("value(char): " + pair.Value.ToStr() + ",  ");
            }
            result += ("}\n");

            return result;
        }
    }

    public class VirtualKeyboardBuilder : MonoBehaviour
    {
        public TextAsset[] AlternateKeySelectorConfigFiles;
        public TextAsset[] LayoutConfigFiles;
        
        private readonly float DEFAULT_WIDTH_WEIGHT = 1.0f;

        private JSONParser _jsonParser;
        private SortedDictionary<Code, LocaleDesc> _localeMap = new SortedDictionary<Code, LocaleDesc>();
        private SortedDictionary<string, List<LabeledKey>> _alternateKeySelectorMap =
            new SortedDictionary<string, List<LabeledKey>>();

        public bool Init()
        {
            Debug.Log("Initializing virtual keyboard builder");
            Clear();
            _jsonParser = new JSONParser();
            foreach (TextAsset file in AlternateKeySelectorConfigFiles)
            {
                bool success = BuildAlternateKeySelectorMap(file);
                Debug.Log("Build AlternateKeySelectorMap using " + file.name + ", success: " + success);
                if (!success)
                {
                    return false;
                }
            }
            foreach (TextAsset file in LayoutConfigFiles)
            {
                bool success = BuildLayouts(file);
                Debug.Log("Build Layouts using " + file.name + ", success: " + success);
                if (!success)
                {
                    return false;
                }
            }
            Debug.Log("Init() of VirtualKeyboardBuilder successfully finished");
            return true;
        }

        public SortedDictionary<Code, LocaleDesc> GetLocaleMap()
        {
            return _localeMap;
        }
        
        private void Clear()
        {
            _jsonParser = null;
            _localeMap.Clear();
            _alternateKeySelectorMap.Clear();
        }

        private bool BuildAlternateKeySelectorMap(TextAsset textAsset)
        {
            AlternateKeySelectorConfig_JSON alternateKeySelectorConfig =
                _jsonParser.ParseAlternateKeySelectorConfig(textAsset);
            if (alternateKeySelectorConfig == null)  
            {   
                Debug.LogError("JSON parser returns null when parsing alternative key selector config");
                return false;
            }
            Debug.Log("Parsed JSON obj of alternate key selector map is: " +
                      JsonUtility.ToJson(alternateKeySelectorConfig));

            if (alternateKeySelectorConfig.AlternateKeyGroups == null)
            {
                Debug.LogError("The AlternateKeyGroups array is required but not present!");
                return false;
            }
            foreach (AlternateKeyGroup_JSON alternateKeyGroup in alternateKeySelectorConfig.AlternateKeyGroups)
            {
                if (alternateKeyGroup.AlternateKeyGroupID == null)
                {
                    Debug.LogError("The AlternateKeyGroupID value is required but not present!");
                    return false;
                }
                _alternateKeySelectorMap.Add(alternateKeyGroup.AlternateKeyGroupID, new List<LabeledKey>());
                if (alternateKeyGroup.AlternateKeys == null)
                {
                    Debug.LogError("The AlternateKeys array is required but not present!");
                    return false;
                }
                if (alternateKeyGroup.AlternateKeys.Length == 0)
                {
                    Debug.LogError("At lease one Key is required but no present!");
                    return false;
                }

                // Read the list of alternate keys
                foreach (AlternateKey_JSON alternateKey in alternateKeyGroup.AlternateKeys)
                {
                    U32string u32string = new U32string(alternateKey.Key);
                    _alternateKeySelectorMap[alternateKeyGroup.AlternateKeyGroupID].Add(
                        new LabeledKey(u32string.Data[0], u32string)
                    );
                }
            }
            return true;
        }

        private bool BuildLayouts(TextAsset textAsset)
        {
            LayoutConfig_JSON layoutConfig = _jsonParser.ParsePageLayout(textAsset);

            if (layoutConfig == null)
            {
                Debug.LogError("JSON parser returns null when parsing page layout");
                return false;
            }

            if (string.IsNullOrEmpty(layoutConfig.LanguageID))
            {
                Debug.LogError("The LanguageID value is required but not present");
                return false;
            }

            LocaleDesc localeDescRef = BuildLanguage(layoutConfig.LanguageID);

            if (localeDescRef == null)
            {
                Debug.LogError("Supported LanguagedID not found!");
                return false;
            }

            if (layoutConfig.PageLayouts == null)
            {
                Debug.LogError("The PageLayouts array is required but not present!");
                return false;
            }

            if (layoutConfig.PageLayouts.Length == 0)
            {
                Debug.LogError("At least one PageLayout is required but not present!");
                return false;
            }

            foreach (PageLayout_JSON pageLayout in layoutConfig.PageLayouts)
            {
                PageLayoutDesc pageLayoutDescRef = BuildPageLayout(localeDescRef, pageLayout);

                if (pageLayoutDescRef == null)
                {
                    Debug.LogError("Supported PageLayoutID not found!");
                    return false;
                }

                if (pageLayout.KeyRows == null)
                {
                    Debug.LogError("The KeyRows array is required but not present");
                    return false;
                }

                if (pageLayout.KeyRows.Length == 0)
                {
                    Debug.LogError("At least one KeyRow is required but not present!");
                    return false;
                }

                foreach (KeyRow_JSON keyRow in pageLayout.KeyRows)
                {
                    List<KeyLayoutDesc> keys = BuildKeyRow(pageLayoutDescRef); //add one row

                    if (keyRow.KeyRow.Length == 0)
                    {
                        Debug.LogError("At least one key is required but not present!");
                        return false;
                    }

                    foreach (Key_JSON key in keyRow.KeyRow)
                    {
                        BuildKey(keys, key);
                    }
                }
            }

            if (layoutConfig.KeyboardPageSets == null)
            {
                Debug.LogError("The KeyboardPageSets value is required but not present!");
                return false;
            }

            if (layoutConfig.KeyboardPageSets.Length == 0)
            {
                Debug.LogError("At least one KeyboardPageSet is required but not present!");
                return false;
            }

            foreach (KeyboardPageSet_JSON keyboardPageSet in layoutConfig.KeyboardPageSets)
            {
                PageLayoutProperties pageLayoutProperties = BuildKeyboardPageSet(
                    localeDescRef, keyboardPageSet
                );

                if (keyboardPageSet.KeyboardPageSetProperties == null) //"kNumeric" "kNumericOnly"
                {
                    continue;
                }

                foreach (KeyboardPageSetProperty_JSON keyboardPageSetProperty in keyboardPageSet.KeyboardPageSetProperties)
                {
                    if (pageLayoutProperties == null)
                    {
                        Debug.LogError("Supported KeyboardPageSetID not found!");
                        return false;
                    }
                    PageID? pageCode = GetPageCode(keyboardPageSetProperty.PageLayoutID);
                    if (pageCode == null)
                    {
                        Debug.LogError(
                            "Cannot BuildKeyboardPageSetProperty() due to unsuupported PageLayoutID!");
                        return false;
                    }

                    if (keyboardPageSetProperty.KeyPage == null)
                    {
                        Debug.LogError("The KeyPage array is required but not present!");
                        return false;
                    }

                    if (keyboardPageSetProperty.KeyPage.Length == 0)
                    {
                        Debug.LogError("At least one KeyPage is required but not present!");
                        return false;
                    }

                    // TO DO: Change this into a map instead of a list
                    KeyTypePageLinkVec keyPages = BuildKeyboardPageSetProperty(
                        pageLayoutProperties, pageCode.Value
                    );

                    foreach (KeyPage_JSON keyPage in keyboardPageSetProperty.KeyPage)
                    {
                        BuildKeyPage(keyPages, keyPage, pageCode.Value);
                    }
                }
            }

            if (layoutConfig.SwappableLabelKeys != null && layoutConfig.SwappableLabelKeys.Length > 0)
            {
                foreach (SwappableLabelKey_JSON swappableLabelKey in layoutConfig.SwappableLabelKeys)
                {
                    List<U32string> labels = BuildSwappableLabelKey(localeDescRef, swappableLabelKey);

                    if (labels == null)
                    {
                        Debug.LogError("Swappable Label Key could not be created!");
                        return false;
                    }

                    foreach (Label_JSON label in swappableLabelKey.Labels)
                    {
                        BuildSwappableLabelKeyLabel(labels, label);
                    }
                }
            }

            return true;
        }

        private Code StringToLocale(string val)
        {
            Dictionary<string, Code> umap = new Dictionary<string, Code>{
                {"kEn_US_Unity", Code.kEn_US_Unity},
                {"kJp_JP_Unity", Code.kJp_JP_Unity}
            };
            if (umap.ContainsKey(val))
            {
                return umap[val];
            }
            else
            {
                Debug.LogWarning("Unknow locale: " + val + ", using default EN US");
                return Code.kEn_US_Unity;
            }
        }

        private PageID? GetPageCode(string val)
        {
            Dictionary<string, PageID> umap = new Dictionary<string, PageID>{
                {"kLowerLetters", (PageID)PageCode.kLowerLetters},
                {"kUpperLetters", (PageID)PageCode.kUpperLetters},
                {"kLowerLettersEmail", (PageID)PageCode.kLowerLettersEmail},
                {"kUpperLettersEmail", (PageID)PageCode.kUpperLettersEmail},
                {"kNumericSymbols", (PageID)PageCode.kNumericSymbols},
                {"kNumericSymbolsAlt", (PageID)PageCode.kNumericSymbolsAlt},
                {"kNumericOnly", (PageID)PageCode.kNumericOnly},
                {"kEmoji", (PageID)PageCode.kEmoji},
                {"kHiragana", (PageID)PageCode.kHiragana},
                {"kKatakana", (PageID)PageCode.kKatakana},
                {"kLowerLettersURL", (PageID)PageCode.kLowerLettersURL},
                {"kUpperLettersURL", (PageID)PageCode.kUpperLettersURL}
            };
            if (umap.ContainsKey(val))
            {
                return umap[val];
            }
            else
            {
                Debug.LogError("Unsupported pageLayoutID: " + val);
                return null;
            }
        }

        KeyType GetKeyType(string val)
        {
            Dictionary<string, KeyType> umap = new Dictionary<string, KeyType> {
                {"kCharacter", KeyType.kCharacter},
                {"kBackspace", KeyType.kBackspace},
                {"kShift", KeyType.kShift},
                {"kSpeechToText", KeyType.kSpeechToText},
                {"kPageEmoji", KeyType.kPageEmoji},
                {"kPageLowerLetters", KeyType.kPageLowerLetters},
                {"kPageNumericSymbols", KeyType.kPageNumericSymbols},
                {"kCancel", KeyType.kCancel},
                {"kSubmit", KeyType.kSubmit},
                {"kPrevious", KeyType.kPrevious},
                {"kNext", KeyType.kNext},
                {"kClear", KeyType.kClear},
                {"kClose", KeyType.kClose},
                {"kEnter", KeyType.kEnter},
                {"kCustom1", KeyType.kCustom1},
                {"kCustom2", KeyType.kCustom2},
                {"kCustom3", KeyType.kCustom3},
                {"kCustom4", KeyType.kCustom4},
                {"kCustom5", KeyType.kCustom5},
                {"kChangeLocale", KeyType.kChangeLocale},
                {"kPageHiragana", KeyType.kPageHiragana},
                {"kPageKatakana", KeyType.kPageKatakana},
                {"kAltCharToggle", KeyType.kAltCharToggle},
                {"kAutoAlternateSelector", KeyType.kAutoAlternateSelector},
                {"kSettings", KeyType.kSettings},
                {"kSpacebar", KeyType.kSpacebar},
                {"kNearFar", KeyType.kNearFar},
                {"kCursorLeft", KeyType.kCursorLeft},
                {"kCursorRight", KeyType.kCursorRight},
                {"kPaste", KeyType.kPaste},
                {"kHidePassword", KeyType.kHidePassword},
                {"kShowPassword", KeyType.kShowPassword},
                {"kTab", KeyType.kTab},
                {"kCharacterSpecial", KeyType.kCharacterSpecial}
            };
            if (!umap.ContainsKey(val))
            {
                Debug.LogError("Unsupported KeyTypeID: " + val);
                return KeyType.kNone;
            }
            return umap[val];
        }

        KeyButtonStyle GetKeyButtonStyle(string val)
        {
            Dictionary<string, KeyButtonStyle> umap = new Dictionary<string, KeyButtonStyle> {
                {"kDefault", KeyButtonStyle.kDefault},
                {"kLight", KeyButtonStyle.kLight},
                {"kMedium", KeyButtonStyle.kMedium},
                {"kDark", KeyButtonStyle.kDark},
            };
            if (!umap.ContainsKey(val))
            {
                Debug.LogError("Unsupported KeyTypeID: " + val);
                return KeyButtonStyle.kDefault;
            }
            return umap[val];
        }

        private LayoutType? GetLayoutType(string val)
        {
            Dictionary<string, LayoutType> umap = new Dictionary<string, LayoutType>
            {
                {"kFull", LayoutType.kFull},
                {"kEmail", LayoutType.kEmail},
                {"kBasic", LayoutType.kBasic},
                {"kNumeric", LayoutType.kNumeric},
                {"kNumericSymbols", LayoutType.kNumericSymbols},
                {"kURL", LayoutType.kURL}
            };
            if (!umap.ContainsKey(val))
            {
                Debug.LogError("Unsupported KeyboardPageSetID: %s" + val);
                return null;
            }
            else
            {
                return umap[val];
            }
        }

        private LinkButton GetLinkButton(string linkButtonString)
        {
            Dictionary<string, LinkButton> linkButtonStringToEnum = new Dictionary<string, LinkButton>
            {
                {"kNone",        LinkButton.kNone},
                {"kCenterLeft",  LinkButton.kCenterLeft},
                {"kCenterRight", LinkButton.kCenterRight},
                {"kLowerLeft",   LinkButton.kLowerLeft},
                {"kLowerRight",  LinkButton.kLowerRight},
                {"kUpperLeft",   LinkButton.kUpperLeft},
                {"kUpperRight",  LinkButton.kUpperRight}
            };
            if (!linkButtonStringToEnum.ContainsKey(linkButtonString))
            {
                return LinkButton.kNone;
            }
            else
            {
                return linkButtonStringToEnum[linkButtonString];
            }
        }

        private LocaleDesc BuildLanguage(string languageID)
        {
            Code localeCode = StringToLocale(languageID);
            _localeMap.Add(localeCode, new LocaleDesc());
            return _localeMap[localeCode];
        }

        private PageLayoutDesc BuildPageLayout(LocaleDesc localeDescription, PageLayout_JSON pageLayout)
        {
            Vector3 defaultKeySize = new Vector3(
                (float)pageLayout.DefaultKeySizeX,
                (float)pageLayout.DefaultKeySizeY,
                (float)pageLayout.DefaultKeySizeZ
            );

            float keyboardWidth = pageLayout.KeyboardWidth;
            float keyGap = pageLayout.KeyGap;

            PageID? pageCode = GetPageCode(pageLayout.PageLayoutID);

            if (!pageCode.HasValue)
            {
                Debug.LogError("Aborting BuildPageLayout early due to unsupported PagelayoutID");
                return null;
            }

            localeDescription.LayoutMap.Add(pageCode.Value, new PageLayoutDesc());
            localeDescription.LayoutMap[pageCode.Value].DefaultKeySize = defaultKeySize;
            localeDescription.LayoutMap[pageCode.Value].KeyboardWidth = keyboardWidth;
            localeDescription.LayoutMap[pageCode.Value].KeyGap = keyGap;

            return localeDescription.LayoutMap[pageCode.Value];
        }

        private List<KeyLayoutDesc> BuildKeyRow(PageLayoutDesc pageLayoutDesc)
        {
            List<KeyLayoutDesc> keyRow = new List<KeyLayoutDesc>();
            pageLayoutDesc.KeyLayoutRows.Add(keyRow);
            int index = pageLayoutDesc.KeyLayoutRows.Count - 1;
            return pageLayoutDesc.KeyLayoutRows[index];
        }

        private void BuildKey(List<KeyLayoutDesc> keyRow, Key_JSON key)
        {
            List<LabeledKey> labeledKeys = new List<LabeledKey>();
            LabeledKey defaultLabeledKey = new LabeledKey();
            string defaultChar = "";
            string alternateKeySelectorID = "";
            float widthWeight = DEFAULT_WIDTH_WEIGHT;
            float gapOnLeft = 0.0f;

            if (key.WidthWeight != null)
            {
                widthWeight = float.Parse(key.WidthWeight);
                if (widthWeight <= 0.0f)
                {
                    Debug.LogError("Bad WidthWeight value, expected positive number.");
                    return;
                }
            }

            if (key.AlternateKeySelectorID != null)
            {
                alternateKeySelectorID = key.AlternateKeySelectorID;
            }

            if (key.DefaultChar != null)
            {
                defaultChar = key.DefaultChar;
            }

            if (key.KeyTypeID == null)
            {
                Debug.LogError("The KeyTypeID key is required but not present!");
                return;
            }

            if (key.GapOnLeft != null)
            {
                gapOnLeft = float.Parse(key.GapOnLeft);
                if (gapOnLeft < 0.0f)
                {
                    Debug.LogError("Bad GapOnLeft value, expected positive number");
                    return;
                }
            }

            KeyButtonStyle style = KeyButtonStyle.kDefault;
            if (key.KeyButtonStyle != null)
            {
                style = GetKeyButtonStyle(key.KeyButtonStyle);
            }

            string keyTypeStr = key.KeyTypeID;
            KeyType keyType = GetKeyType(keyTypeStr);
            if (keyType == KeyType.kNone)
            {
                Debug.LogError("Aborting BuildKey early due to unsupported KeyTypeID: " + keyTypeStr);
            }

            if (_alternateKeySelectorMap.ContainsKey(alternateKeySelectorID))
            {
                // Make a new copy here
                labeledKeys = new List<LabeledKey>(_alternateKeySelectorMap[alternateKeySelectorID]);
            }

            if (!string.IsNullOrEmpty(defaultChar))
            {
                U32string defaultChar32 = new U32string(defaultChar);
                defaultLabeledKey.Label = defaultChar32;
                defaultLabeledKey.CharacterCode = defaultChar32.Data[0];
            }

            keyRow.Add(new KeyLayoutDesc(new KeyDesc(keyType, defaultLabeledKey, labeledKeys), 
                       widthWeight, 
                       gapOnLeft, 
                       style));
        }

        private PageLayoutProperties BuildKeyboardPageSet(LocaleDesc localeDescription,
                                                          KeyboardPageSet_JSON keyboardPageSet)
        {
            LayoutType? layoutType = GetLayoutType(keyboardPageSet.KeyboardPageSetID);

            if (layoutType == null)
            {
                Debug.LogError("Aborting BuildKeyboardPageSet early due to unsupported KeyboardPageSetID!");
                return null;
            }

            PageID? pageCode = GetPageCode(keyboardPageSet.PageLayoutID);

            if (pageCode == null)
            {
                Debug.LogError("Aborting BuildKeyboardPageSet early due to unsupported PageLayoutID!");
                return null;
            }

            localeDescription.PropertyMap.Add(layoutType.Value, new PageLayoutProperties());

            localeDescription.PropertyMap[layoutType.Value].DefaultPage = pageCode.Value;

            return localeDescription.PropertyMap[layoutType.Value];
        }

        private KeyTypePageLinkVec BuildKeyboardPageSetProperty(
            PageLayoutProperties pageLayoutProperties, PageID pageCode)
        {
            pageLayoutProperties.PageLinkMap.Add(pageCode, new KeyTypePageLinkVec());
            return pageLayoutProperties.PageLinkMap[pageCode];
        }

        private void BuildKeyPage(KeyTypePageLinkVec keyPages, KeyPage_JSON keyPage, PageID defaultPageCode)
        {
            string keyTypeStr = keyPage.KeyTypeID;
            KeyType keyType = GetKeyType(keyTypeStr);

            if (keyType == KeyType.kNone)
            {
                Debug.LogError("Aborting BuildKeyPage early due to unsupported KeyTypeID: " + keyTypeStr);
            }

            string pageLayoutIDString = keyPage.PageLayoutID;
            PageID? pageCode = string.IsNullOrEmpty(pageLayoutIDString) ?
                              defaultPageCode : GetPageCode(pageLayoutIDString);
            if (pageCode == null)
            {
                pageCode = defaultPageCode;
            }

            keyPages.Add(new KeyValuePair<KeyType, PageLink>(
                keyType, new PageLink(pageCode.Value)));
        }

        private List<U32string> BuildSwappableLabelKey(LocaleDesc localeDescription,
                                                    SwappableLabelKey_JSON swappableLabelKey)
        {
            if (swappableLabelKey.KeyTypeID == null)
            {
                Debug.LogError("The KeyTypeID value is required but not present!");
                return null;
            }

            if (swappableLabelKey.Char == null)
            {
                Debug.LogError("The Char value is required but not present!");
                return null;
            }

            string keyTypeStr = swappableLabelKey.KeyTypeID;
            KeyType keyType = GetKeyType(keyTypeStr);
            if (keyType == KeyType.kNone)
            {
                Debug.LogError(
                    "Aborting BuildSwappableLabelKey early due to unsupported KeyTypeID: " + keyTypeStr);
                return null;
            }

            localeDescription.AdditionalKeyLabels.Add(keyType, new MultiLabeledKey());

            string character = swappableLabelKey.Char;
            U32string character32 = new U32string(character);
            localeDescription.AdditionalKeyLabels[keyType].CharacterCode = character32.Data[0];

            return localeDescription.AdditionalKeyLabels[keyType].Labels;
        }

        private void BuildSwappableLabelKeyLabel(List<U32string> labels, Label_JSON label)
        {
            if (string.IsNullOrEmpty(label.Label))
            {
                Debug.LogError("The Label key is required but not present!");
                return;
            }
            labels.Add(new U32string(label.Label));
        }

        private void PrintAll()
        {
            string path = "Assets/PrintAllBuilderInfo.txt";

            FileInfo fi = new FileInfo(path);
            using (TextWriter txtWriter = new StreamWriter(fi.Open(FileMode.Truncate)))
            {
                txtWriter.WriteLine("_alternateKeySelectorMap is: ");
                foreach (KeyValuePair<string, List<LabeledKey>> pair in _alternateKeySelectorMap)
                {
                    txtWriter.WriteLine("selector ID: " + pair.Key);
                    string labeledKeysStr = "labeled keys: ";
                    foreach (LabeledKey key in pair.Value)
                    {
                        labeledKeysStr += ("LabeledKey {CharacterCode: " + key.CharacterCode.ToStr() +
                                           "; label: " + key.Label.ToStr() + "}, ");
                    }
                    txtWriter.WriteLine(labeledKeysStr);
                }

                txtWriter.WriteLine("\n\n##########################################");

                txtWriter.WriteLine("_localeMap is: ");
                foreach (KeyValuePair<Code, LocaleDesc> pair in _localeMap)
                {
                    txtWriter.WriteLine("key (Code): " + pair.Key);
                    txtWriter.WriteLine("value (LocaleDesc): " + pair.Value.ToStr() + "\n");
                }
                txtWriter.Close();
            }
        }
    }
}