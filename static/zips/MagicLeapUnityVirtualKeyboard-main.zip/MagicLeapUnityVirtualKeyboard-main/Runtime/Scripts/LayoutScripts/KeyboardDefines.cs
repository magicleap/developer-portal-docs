// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using System;
using System.Text;
using UnityEngine;

namespace MagicLeap.Keyboard
{
    public enum Code
    {
        kEn_US_Unity,
        kJp_JP_Unity
    }

    public enum PageCode
    {
        kLowerLetters,
        kUpperLetters,
        kLowerLettersEmail,
        kUpperLettersEmail,
        kNumericSymbols,
        kNumericSymbolsAlt,
        kNumericOnly,
        kEmoji,
        kHiragana,
        kKatakana,
        kLowerLettersURL,
        kUpperLettersURL
    }

    public enum KeyType
    {
        kNone,
        kCharacter,
        kBackspace,
        kShift,
        kSpeechToText,
        kPageEmoji,
        kPageLowerLetters,
        kPageNumericSymbols,
        kCancel,
        kSubmit,
        kPrevious,
        kNext,
        kClear,
        kClose,
        kEnter,
        kCustom1,
        kCustom2,
        kCustom3,
        kCustom4,
        kCustom5,
        kChangeLocale,
        kPageHiragana,
        kPageKatakana,
        kAltCharToggle,
        kAutoAlternateSelector,
        kSettings,
        kSpacebar,
        kNearFar,
        kCursorLeft,
        kCursorRight,
        kPaste,
        kHidePassword,
        kShowPassword,
        kTab,
        kCharacterSpecial,
        kSuggestion
    }

    public enum KeyButtonStyle
    {
        kDefault,
        kLight,
        kMedium,
        kDark
    }

    public enum LayoutType
    {
        kFull,
        kEmail,
        kBasic,
        kNumeric,
        kNumericSymbols,
        kURL
    }

    public struct U32string
    {
        public Char32_t[] Data;

        // Copy constructor
        public U32string(U32string a_U32string)
        {
            Data = new Char32_t[a_U32string.Data.Length];
            for (int i = 0; i < Data.Length; i++)
            {
                Data[i] = a_U32string.Data[i];
            }
        }

        // Can be constructed from a regular string
        public U32string(string a_string)
        {
            var enc = new UTF32Encoding(true, false, false);
            var byteLen = enc.GetByteCount(a_string);
            if (byteLen % 4 != 0)
            {
                Debug.LogWarning("Converting string of " + a_string +
                          " to Bytes resulted in irregular number of bytes");
            }
            Data = new Char32_t[byteLen / 4];
            Byte[] encodedBytes = enc.GetBytes(a_string);
            for (int i = 0; i < (byteLen / 4); i++)
            {
                Data[i] = new Char32_t(
                    encodedBytes[i * 4],
                    encodedBytes[i * 4 + 1],
                    encodedBytes[i * 4 + 2],
                    encodedBytes[i * 4 + 3]
                );
            }
        }

        public override bool Equals(object obj) => obj is U32string other && this.Equals(other);
        public bool Equals(U32string other)
        {
            if (this.Data == null && other.Data == null)
            {
                return true; // both null, equal
            }

            if (this.Data == null || other.Data == null)
            {
                return false; // only one is null, not equal
            }

            if (this.Data.Length != other.Data.Length)
            {
                return false; // length not euqal
            }

            for (int i = 0; i < this.Data.Length; i++)
            {
                if (this.Data[i] != other.Data[i])
                {
                    return false;
                }
            }
            return true;
        }
        public override int GetHashCode() => base.GetHashCode();
        public static bool operator ==(U32string lhs, U32string rhs) => lhs.Equals(rhs);
        public static bool operator !=(U32string lhs, U32string rhs) => !lhs.Equals(rhs);

        public string ToStr()
        {
            if (Data == null)
            {
                return "NULL";
            }
            Byte[] bytes = new Byte[Data.Length * 4];
            for (int i = 0; i < Data.Length; i++)
            {
                bytes[i * 4] = Data[i].Byte0;
                bytes[i * 4 + 1] = Data[i].Byte1;
                bytes[i * 4 + 2] = Data[i].Byte2;
                bytes[i * 4 + 3] = Data[i].Byte3;
            }
            var enc = new UTF32Encoding(true, false, false);
            return enc.GetString(bytes);
        }
    }

    public struct Char32_t
    {
        public Byte Byte0;
        public Byte Byte1;
        public Byte Byte2;
        public Byte Byte3;

        public Char32_t(Byte b0, Byte b1, Byte b2, Byte b3)
        {
            Byte0 = b0; Byte1 = b1; Byte2 = b2; Byte3 = b3;
        }

        // Overload the quals operator
        public override bool Equals(object obj) => obj is Char32_t && this.Equals(obj);
        public bool Equals(Char32_t other) => Byte0 == other.Byte0 && Byte1 == other.Byte1 && 
                                              Byte2 == other.Byte2 && Byte3 == other.Byte3;
        
        public override int GetHashCode() => (Byte0, Byte1, Byte2, Byte3).GetHashCode();
        public static bool operator ==(Char32_t lhs, Char32_t rhs) => lhs.Equals(rhs);
        public static bool operator !=(Char32_t lhs, Char32_t rhs) => !(lhs == rhs);

        public string ToStr()
        {
            var enc = new UTF32Encoding(true, false, false);
            Byte[] bytes = new Byte[] { Byte0, Byte1, Byte2, Byte3 };
            return enc.GetString(bytes);
        }
    }

    public struct LabeledKey
    {
        public Char32_t CharacterCode;
        public U32string Label;

        public LabeledKey(Char32_t a_CharacterCode, string a_label)
        {
            CharacterCode = a_CharacterCode;
            Label = new U32string(a_label);
        }
        public LabeledKey(Char32_t a_characgterCode, U32string a_U32string)
        {
            CharacterCode = a_characgterCode;
            Label = new U32string(a_U32string);
        }

        public string ToStr()
        {
            return ("LabeledKey {CharacterCode: " + CharacterCode.ToStr() +
                    "; Label: " + Label.ToStr() + "} ");
        }
    }

    public class MultiLabeledKey
    {
        public Char32_t CharacterCode;
        public List<U32string> Labels;

        public MultiLabeledKey()
        {
            CharacterCode = new Char32_t();
            Labels = new List<U32string>();
        }

        public string ToStr()
        {
            string labelsStr = "Labels: ";
            foreach (U32string label in Labels)
            {
                labelsStr += (label.ToStr() + ", ");
            }
            return "MultiLabeledKey {CharacterCode: " + CharacterCode.ToStr() + "; Labels: " + labelsStr + "} ";
        }
    }

    public struct KeyDesc
    {
        public KeyType KeyType;
        public LabeledKey DefaultLabeledKey;
        public List<LabeledKey> AlternativeLabeledKeys;

        public KeyDesc(KeyType aKeyType, LabeledKey aDefaultLabeledKey, List<LabeledKey> anAlternativeLabeledKeys)
        {
            KeyType = aKeyType;
            DefaultLabeledKey = aDefaultLabeledKey;
            AlternativeLabeledKeys = anAlternativeLabeledKeys;
        }

        public string ToStr()
        {
            string alternativeLabedKeysStr = "AlternativeLabeledKeys: ";
            foreach (LabeledKey labeledKey in AlternativeLabeledKeys)
            {
                alternativeLabedKeysStr += (labeledKey.ToStr() + ", ");
            }
            return "KeyDesc {KeyType: " + KeyType + "; DefaultLabeledKey: " + DefaultLabeledKey.ToStr() +
                   "; AlternativeLabeledKeys: " + alternativeLabedKeysStr + "} ";
        }
    }

    public class KeyboardDefines : MonoBehaviour
    {
    }
}
