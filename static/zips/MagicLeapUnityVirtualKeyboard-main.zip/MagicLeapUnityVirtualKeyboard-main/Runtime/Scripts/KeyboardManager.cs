// Copyright (c) 2019-present, Magic Leap, Inc. All Rights Reserved.
// Use of this file is governed by the Developer Agreement, located
// here: https://auth.magicleap.com/terms/developer

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using TMPro;
using UnityEngine.Events;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System;

namespace MagicLeap.Keyboard
{
    using PageID = System.UInt32;

    [System.Serializable]
    public class PublishKeyEvent: UnityEvent<string, KeyType, bool, string>{}

    public class KeyboardManager : MonoBehaviour
    {
        static readonly float DISPLAY_BAR_Y_OFFSET = 0.02f;

        public PublishKeyEvent PublishKeyEvent;

        public Code Locale = Code.kEn_US_Unity;

        public string TypedContent = "";
        
        [SerializeField] private bool _printDebugInfo = false;

        [SerializeField] private bool _reloadLayoutsOnStart = false;

        [SerializeField] private GameObject _layoutsParent;
        [SerializeField] private TMP_InputField _tmpInputField = null;
        [SerializeField] private GameObject _displayBar = null;
        [SerializeField] private DisplayBarInfo _displayBarInfo = null;

        [SerializeField] private GameObject _engLayouts;
        [SerializeField] private GameObject _japanLayouts;

        [SerializeField] private TextAsset _en_US_dict;

        private bool _initialized = false;
        private VirtualKeyboardBuilder _virtualKeyboardBuilder;
        private PageCode _pageCode = PageCode.kLowerLetters;
        private LayoutType _layoutType = LayoutType.kFull; // currently only support this one
        private Dictionary<Code, GameObject> _languageToPrefabMap = new Dictionary<Code, GameObject>();
        private Vector3 _curLayoutExtents = new Vector3(
            0.42f, 0.12f, VirtualKeyboardLayoutGen.DEFAULT_KEYBOARD_THICKNESS);

        private Code _cacheLastLocale = Code.kEn_US_Unity;
        private PageCode _cacheLastPageCode = PageCode.kLowerLetters;
        
        private bool _tempCaps = false;

        /***********************************************************************/
        /************ Word Suggestion Related Variables ************************/
        /***********************************************************************/
        private static int NUM_SUGGESTIONS = 4;
        private static int NUM_CANDIDATES = 20;
        
        public bool ExperimentalWordSuggestion = true;

        [SerializeField] private GameObject _suggestionsParent = null;
        [SerializeField] private TextMeshPro[] _suggestionsTextMeshes;

        private Prediction _prediction;
        private volatile List<int> _wordBeginOffsets = new List<int>();
        private volatile List<int> _wordEndOffsets = new List<int>();
        private volatile StringBuilder _curWord = new StringBuilder();
        private volatile bool _growingCurWord = false;

        private CancellationToken _predictCancelToken;
        private volatile CancellationTokenSource _predictCancelTokenSrc;
        private volatile Task<List<Suggestion>> _launchedTask = null;

        private bool Init()
        {
            if (!_initialized)
            {
                _virtualKeyboardBuilder = GetComponent<VirtualKeyboardBuilder>();
                if (!_virtualKeyboardBuilder)
                {
                    Debug.LogError("Cannot find VirtualKeyboardBuilder! Abort!");
                    return false;
                }
                bool success = _virtualKeyboardBuilder.Init();
                if (!success)
                {
                    Debug.LogError("_virtualKeyboardBuilder init failed!");
                    return false;
                }
                CreateLanguageToPrefabMap();
                _suggestionsParent.SetActive(false);
                _prediction = new Prediction();
                _prediction.Init(_en_US_dict); //hack, as we currently only support English
                _initialized = true;
            }
            return true;
        }

        public void EditorReloadLayouts()
        {
#if UNITY_EDITOR
            // We have to unpack the prefab first here if we want to modify it in Editor
            if (PrefabUtility.IsAnyPrefabInstanceRoot(gameObject))
            {
                PrefabUtility.UnpackPrefabInstance(gameObject, PrefabUnpackMode.Completely, InteractionMode.UserAction);
            }
#endif
            CreateLanguageToPrefabMap();
            if (!_languageToPrefabMap.ContainsKey(Locale))
            {
                Debug.LogError("Cannot find the layouts prefab for this language: " + Locale);
                return;
            }
            EditorClearLayouts(_layoutsParent);
            _layoutsParent = GameObject.Instantiate(_languageToPrefabMap[Locale], this.transform);
            foreach (Transform child in _layoutsParent.transform)
            {
                if (child.gameObject.activeInHierarchy) //Find the one that'll be first used
                {
                    LayoutInfo layoutInfo = child.gameObject.GetComponent<LayoutInfo>();
                    if (layoutInfo)
                    {
                        _curLayoutExtents = layoutInfo.Extents;
                    }
                }
            }
            ConfigDisplayBar(_curLayoutExtents);
        }

        private void CreateLanguageToPrefabMap()
        {
            _languageToPrefabMap.Clear();
            _languageToPrefabMap.Add(Code.kEn_US_Unity, _engLayouts);
            _languageToPrefabMap.Add(Code.kJp_JP_Unity, _japanLayouts);
        }

        private PageLayoutProperties GetPageLayoutProperties(Code localeCode, LayoutType layoutType)
        {
            if (!_virtualKeyboardBuilder.GetLocaleMap().ContainsKey(localeCode))
            {
                Debug.LogError("Could not find map entry for locale: " + localeCode);
                return null;
            }
            LocaleDesc localeDesc = _virtualKeyboardBuilder.GetLocaleMap()[localeCode];
            if (!localeDesc.PropertyMap.ContainsKey(layoutType))
            {
                Debug.LogError("Could not find layout type in that locale, layoutType: " + layoutType);
                return null;
            }
            return localeDesc.PropertyMap[layoutType];
        }

        private void ClearLayouts(GameObject layoutsParent)
        {
            if (_layoutsParent)
            {
                GameObject.Destroy(_layoutsParent);
                _layoutsParent = null;
            }
        }

        private void EditorClearLayouts(GameObject layoutsParent)
        {
            if (layoutsParent == null)
            {
                return;
            }

            GameObject.DestroyImmediate(_layoutsParent);
            _layoutsParent = null;
        }

        private void ConfigKeys(GameObject keysParent)
        {
            if (!keysParent) 
            {
                Debug.LogError("Cannot find the parent of keys when configuring keys!");
                return;
            }
            foreach (Transform child in keysParent.transform)
            {
                ConfigKey(child.gameObject);
            }
        }

        private void ConfigBackground(GameObject backgroundParent)
        {
            if (!backgroundParent) 
            {
                Debug.LogError("Cannot find the parent of background when configuring background!");
                return;
            }

            BackgroundInfo backgroundInfo = backgroundParent.GetComponent<BackgroundInfo>();
            if (!backgroundInfo)
            {
                Debug.LogError("Missing BackgroundInfo script on the keyboard background GameObject, aborting!");
                return;
            }

            GameObject leftHandleParent = backgroundInfo.LeftHandleParent;
            GameObject rightHandleParent = backgroundInfo.RightHandleParent;

            if (!leftHandleParent || !rightHandleParent)
            {
                Debug.LogError("Missing reference to handles on BackgroundInfo script, aborting!");
                return;
            }

            // Connect scripts for the left/right handle
            leftHandleParent.GetComponent<SideHandleAct>()?.SetKeyboardObj(this.gameObject);
            rightHandleParent.GetComponent<SideHandleAct>()?.SetKeyboardObj(this.gameObject);

            leftHandleParent.GetComponent<SideHandleAct>()?.SetDisplayBarObj(_displayBar);
            rightHandleParent.GetComponent<SideHandleAct>()?.SetDisplayBarObj(_displayBar);
        }   

        private void ConfigKey(GameObject keyObj)
        {
            KeyInfo keyInfo = keyObj.GetComponent<KeyInfo>();
            Clickable clickable = keyObj.GetComponent<Clickable>();
            if (!keyInfo || !clickable)
            {
                return;
            }

            clickable.OnClicked.RemoveAllListeners();
            switch (keyInfo.KeyType)
            {
                case KeyType.kCharacter:
                case KeyType.kCharacterSpecial:
                case KeyType.kTab:
                case KeyType.kSpacebar:
                case KeyType.kBackspace:
                    clickable.OnClicked.AddListener(delegate { CharKeyClicked(keyInfo); });
                    break;
                case KeyType.kPageNumericSymbols:
                    clickable.OnClicked.AddListener(delegate { FuncKeyClicked(KeyType.kPageNumericSymbols); });
                    break;
                case KeyType.kShift:
                    clickable.OnClicked.AddListener(delegate { FuncKeyClicked(KeyType.kShift); });
                    clickable.OnDoubleClicked.AddListener(
                        delegate {FuncKeyClicked(KeyType.kShift, true);});
                    break;
                case KeyType.kCustom1:
                    clickable.OnClicked.AddListener(delegate { FuncKeyClicked(KeyType.kCustom1); });
                    break;
                case KeyType.kSuggestion:
                    clickable.OnClicked.AddListener(delegate { SuggestionKeyClicked(keyObj); });
                    break;
                default:
                    if (_printDebugInfo)
                    {
                        Debug.Log("This keytype is skipped when configuring the key: " + keyInfo.KeyType);
                    }
                    break;
            }
        }

        private void ConfigDisplayBar(Vector3 curLayoutExtents)
        {
            _displayBarInfo.ClearKey?.GetComponent<Clickable>()?.OnClicked.AddListener(
                delegate {
                    FuncKeyClicked(KeyType.kClear);
                }
            );
            // Position the top bar items
            if (_displayBar)
            {
                _displayBar.transform.localPosition = new Vector3(
                    _displayBar.transform.localPosition.x,
                    curLayoutExtents.y * 0.5f + VirtualKeyboardLayoutGen.BACKGROUND_EDGE_WIDTH + 
                    DISPLAY_BAR_Y_OFFSET,
                    _displayBar.transform.localPosition.z
                );
            }
        }

        private void CharKeyClicked(KeyInfo keyInfo, bool doubleClick = false)
        {
            if (_tmpInputField && !_tmpInputField.isFocused)
            {
                _tmpInputField.ActivateInputField();
            }

            switch (keyInfo.KeyType)
            {
                case KeyType.kBackspace:
                    if (TypedContent.Length > 0)
                    {
                        ProcessNewCharInput(keyInfo, doubleClick);
                    }
                    break;
                // Add more processes here to handle more types of char keys in the future
                default:
                    ProcessNewCharInput(keyInfo, doubleClick);
                    break;
            }

            // Load back the lower case layout if we were temprarily using upper case
            if (_tempCaps)
            {
                _tempCaps = false;
                LoadLayout(Locale, PageCode.kLowerLetters, false, false);
            }

            PublishKeyEvent.Invoke(keyInfo.TextToType, keyInfo.KeyType, doubleClick, TypedContent);
        }
        
        private void FuncKeyClicked(KeyType keyType, bool doubleClick = false)
        {
            if (_printDebugInfo)
            {
                Debug.Log("Function key clicked: " + keyType);
            }

            if (_tmpInputField && !_tmpInputField.isFocused)
            {
                _tmpInputField.ActivateInputField();
            }

            PageCode nextPageCode = _pageCode;
            Code nextLocale = Locale;
            bool toTempCaps = false;
            if (doubleClick && keyType == KeyType.kShift)
            {
                nextPageCode = _pageCode == PageCode.kUpperLetters ? PageCode.kLowerLetters : PageCode.kUpperLetters;
                LoadLayout(nextLocale, nextPageCode, false, toTempCaps);
            }
            else if (keyType == KeyType.kShift || keyType == KeyType.kPageNumericSymbols)
            {
                var pageLayoutProperties = GetPageLayoutProperties(Locale, _layoutType);
                var pageLinkMap = pageLayoutProperties.PageLinkMap;

                if (!pageLinkMap.ContainsKey((PageID)_pageCode))
                {
                    return;
                }
                var keyPagePairs = pageLayoutProperties.PageLinkMap[(PageID)_pageCode];
                bool found = false;
                foreach (var keyPagePair in keyPagePairs)
                {
                    if (keyPagePair.Key == keyType)
                    {
                        nextPageCode = (PageCode)keyPagePair.Value.ThisPageID;
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    Debug.LogError("could not find this key: " + keyType + " in page link map");
                    return;
                }

                if (nextPageCode == PageCode.kUpperLetters)
                {
                    toTempCaps = true;
                }

                LoadLayout(nextLocale, nextPageCode, false, toTempCaps);
            }
            else if (keyType == KeyType.kClear)
            {
                TypedContent = "";
                if (_tmpInputField)
                {
                    _tmpInputField.text = "";
                    _tmpInputField.caretPosition = 0;
                }
                _growingCurWord = false;
                _wordBeginOffsets.Clear();
                _wordEndOffsets.Clear();
                _curWord.Clear();
                if (_suggestionsParent.activeSelf)
                {
                    _suggestionsParent.SetActive(false);
                }
            }

            PublishKeyEvent.Invoke("", keyType, doubleClick, TypedContent);
        }

        private void SuggestionKeyClicked(GameObject keyObj, bool doubleClick = false)
        {
            if (keyObj.GetComponent<KeyInfo>() == null)
            {
                return;
            }

            if (_tmpInputField && !_tmpInputField.isFocused)
            {
                _tmpInputField.ActivateInputField();
            }
            
            string contentWithoutCurWord = TypedContent.Substring(
                0,
                _wordBeginOffsets[_wordBeginOffsets.Count - 1]);
            string keyText = keyObj.GetComponent<KeyInfo>().TextToType;
            TypedContent = contentWithoutCurWord + keyText + " ";

            _growingCurWord = false;
            _wordEndOffsets.Add(TypedContent.Length-1);

            if (_tmpInputField)
            {
                _tmpInputField.text = TypedContent;
                _tmpInputField.caretPosition = _tmpInputField.text.Length;
            }

            _suggestionsParent.SetActive(false);

            PublishKeyEvent.Invoke(keyText, KeyType.kSuggestion, doubleClick, TypedContent);
        }

        private void PrintInputFieldStatus()
        {
            Debug.Log("Growing current word: " + _growingCurWord + "; current word is: " + _curWord.ToString());
            StringBuilder offsetsInfo = new StringBuilder("begin offsets are: ");
            foreach (int offset in _wordBeginOffsets)
            {
                offsetsInfo.Append(offset + ", ");
            }
            Debug.Log(offsetsInfo.ToString());

            offsetsInfo.Clear();
            offsetsInfo.Append("end offsets are: ");
            foreach (int offset in _wordEndOffsets)
            {
                offsetsInfo.Append(offset + ", ");
            }
            Debug.Log(offsetsInfo.ToString());
        }

        // Let the suggestion engine process the new input
        private async void ProcessNewCharInput(KeyInfo keyInfo, bool doubleClick = false)
        {
            // In case suggestion engine is disabled
            if (!ExperimentalWordSuggestion || _prediction == null || !_prediction.Initialized)
            {
                if (keyInfo.KeyType != KeyType.kBackspace && keyInfo.TextToType.Length > 0)
                {
                    TypedContent += keyInfo.TextToType;
                }
                else if (keyInfo.KeyType == KeyType.kBackspace)
                {
                    TypedContent = TypedContent.Substring(0, TypedContent.Length - 1);
                }

                if (_tmpInputField)
                {
                    _tmpInputField.text = TypedContent;
                    _tmpInputField.caretPosition = _tmpInputField.text.Length;
                }
                return;
            }

            // Below will carry out only if the suggestion engine is enabled

            if (keyInfo.KeyType != KeyType.kBackspace && keyInfo.TextToType.Length > 0)
            {
                foreach (char ch in keyInfo.TextToType)
                {
                    // Composing a word
                    if (_prediction.ValidChars != null && _prediction.ValidChars.Contains(ch))
                    {
                        // Starting a new word
                        if (!_growingCurWord) 
                        {
                            if (_printDebugInfo)
                            {
                                Debug.Log("starting a new word");
                            }
                            _curWord.Clear();
                            _curWord.Append(ch);
                            _growingCurWord = true;
                            _wordBeginOffsets.Add(TypedContent.Length);
                        }
                        // Continuing an already-started word
                        else 
                        {
                            if (_printDebugInfo)
                            {
                                Debug.Log("continuing an already-started word");
                            }
                            _curWord.Append(ch);
                        }
                    }
                    // It's treated as a separator that ends the current word
                    else  
                    {
                        if (_growingCurWord)
                        {
                            if (_printDebugInfo)
                            {
                                Debug.Log("separator");
                            }
                            _curWord.Clear();
                            _growingCurWord = false;
                            _wordEndOffsets.Add(TypedContent.Length);
                        }
                        // Eliminate spaces at the tail if the new input is a symbol (cannot be found in ValidChars)
                        else if (ch != ' ')
                        {
                            int nonEmptyTextEndPos = TypedContent.Length - 1;
                            while (nonEmptyTextEndPos >= 0 && TypedContent[nonEmptyTextEndPos] == ' ')
                                nonEmptyTextEndPos--;

                            TypedContent = TypedContent.Substring(0, nonEmptyTextEndPos + 1);
                        }
                    }
                    TypedContent += ch;
                }
            }
            else if (keyInfo.KeyType == KeyType.kBackspace)
            {
                TypedContent = TypedContent.Substring(0, TypedContent.Length - 1);

                if (_growingCurWord)
                {
                    if (_curWord.Length == 0)
                    {
                        Debug.LogError(
                            "A growing current word should not have a length of 0, something went wrong");
                    }
                    // Shrink the current growing word
                    else
                    {
                        if (_printDebugInfo)
                        {
                            Debug.Log("shrinking the currently growing word");
                        }
                        _curWord.Remove(_curWord.Length-1, 1);
                    }
                    // If we deleted the entire currently growing word
                    if (_curWord.Length == 0) 
                    {
                        if (_printDebugInfo)
                        {
                            Debug.Log("deleting the entire current growing word");
                        }
                        _growingCurWord = false;
                        _wordBeginOffsets.RemoveAt(_wordBeginOffsets.Count - 1);
                    }
                }
                // Else if we reached the end of a previous word
                else if (_wordEndOffsets.Count > 0 &&
                         TypedContent.Length == _wordEndOffsets[_wordEndOffsets.Count-1])
                {
                    if (_printDebugInfo)
                    {
                        Debug.Log("reached the end of a previous word");
                    }
                    _growingCurWord = true;
                    _curWord.Clear();

                    string newGrowingCurWord = TypedContent.Substring(
                        _wordBeginOffsets[_wordBeginOffsets.Count - 1], 
                        _wordEndOffsets[_wordEndOffsets.Count - 1] - 
                        _wordBeginOffsets[_wordBeginOffsets.Count - 1]);

                    _curWord.Append(newGrowingCurWord);
                    _wordEndOffsets.RemoveAt(_wordEndOffsets.Count - 1);
                }
            }

            if (_tmpInputField)
            {
                _tmpInputField.text = TypedContent;
                _tmpInputField.caretPosition = _tmpInputField.text.Length;
            }

            if (_printDebugInfo)
            {
                PrintInputFieldStatus();
            }

            // Launch the word suggestion engine with the current growing word
            if (_growingCurWord && _curWord.Length > 0)
            {
                // Whatever happened before has finished execution
                if (_launchedTask == null || _launchedTask.IsCompleted)
                {
                    if (_printDebugInfo)
                    {
                        Debug.Log("Lauching new prediction with text of: " + _curWord.ToString());
                    }
                }
                else if (_launchedTask != null && !_launchedTask.IsCompleted)
                {
                    if (_printDebugInfo)
                    {
                        Debug.Log("Trying to launch new prediction for " + _curWord.ToString() +
                                  " when previous one has not finished: ");
                        Debug.Log("Canceling the previous prediction before: " + _curWord.ToString());
                    }

                    _predictCancelTokenSrc.Cancel();
                }
                try
                {
                    _predictCancelTokenSrc = new CancellationTokenSource();
                    _predictCancelToken = _predictCancelTokenSrc.Token;
                    _launchedTask = _prediction.LaunchPredict(
                        _curWord.ToString(), NUM_SUGGESTIONS, NUM_CANDIDATES, 1,
                        _predictCancelToken, _predictCancelTokenSrc
                    );
                    await _launchedTask;
                    if (_launchedTask.Status == TaskStatus.RanToCompletion &&
                        _launchedTask.Result.Count == NUM_SUGGESTIONS)
                    {
                        if (!_suggestionsParent.activeSelf)
                        {
                            _suggestionsParent.SetActive(true);
                        }
                        for (int i=0; i<NUM_SUGGESTIONS; i++)
                        {
                            _suggestionsTextMeshes[i].text = _launchedTask.Result[i].TextToType;
                            GameObject suggestionObj = _suggestionsTextMeshes[i].transform.parent?.parent?.gameObject;
                            if (suggestionObj != null && suggestionObj.GetComponent<KeyInfo>() != null)
                            {
                                suggestionObj.GetComponent<KeyInfo>().TextToType = _launchedTask.Result[i].TextToType;
                            }
                        }
                    }
                    else if (_launchedTask.Result.Count != 3 && !_suggestionsParent.activeSelf)
                    {
                        _suggestionsParent.SetActive(false);
                    }
                }
                catch (OperationCanceledException)
                {
                    if (_printDebugInfo)
                    {
                        Debug.Log("Prediction canceled");
                    }
                }
            }
            else if (_suggestionsParent.activeSelf)
            {
                _suggestionsParent.SetActive(false);
            }
        }

        private void LoadLayout(Code nextLocale, PageCode nextPageCode, bool firstLoad = false, bool toTempCaps = false)
        {
            if (_printDebugInfo)
            {
                Debug.Log("Loading layout with Language: " + nextLocale + " PageCode: " + nextPageCode);
            }

            if (nextLocale != Locale || firstLoad) // need to switch in a new asset
            {
                _cacheLastLocale = Locale;
                Locale = nextLocale;

                _cacheLastPageCode = _pageCode;
                _pageCode = nextPageCode;
                
                if (!_languageToPrefabMap.ContainsKey(nextLocale))
                {
                    Debug.LogError("Cannot find the parent of keys when configuring keys!");
                    
                    // Resume original state before aborting
                    Locale = _cacheLastLocale;
                    _pageCode = _cacheLastPageCode;
                    return;
                }
                ClearLayouts(_layoutsParent);
                _layoutsParent = GameObject.Instantiate(_languageToPrefabMap[nextLocale], this.transform);

                ConfigLayouts();
            }
            else // switch within the currently loaded layouts
            {
                if (nextPageCode == _pageCode)
                {
                    return;
                }
                _cacheLastPageCode = _pageCode;
                _pageCode = nextPageCode;
                foreach (Transform child in _layoutsParent.transform)
                {
                    LayoutInfo layoutInfo = child.gameObject.GetComponent<LayoutInfo>();
                    if (layoutInfo.ThisPageCode == nextPageCode)
                    {
                        child.gameObject.SetActive(true);
                        _curLayoutExtents = layoutInfo.Extents;

                        // Adjust Shift key state using materials
                        if (layoutInfo.ThisPageCode == PageCode.kUpperLetters)
                        {
                            ShiftKeyState newState = toTempCaps ? ShiftKeyState.OnTemp : ShiftKeyState.OnPerm;
                            foreach (ShiftKeyBehavior behave in layoutInfo.ShiftKeysBehavs)
                            {
                                behave.SwitchStatus(newState);
                            }
                        }
                    }
                    else 
                        child.gameObject.SetActive(false);
                }
            }
            _tempCaps = toTempCaps;
            ConfigDisplayBar(_curLayoutExtents);
        }

        private void ConfigLayouts()
        {
            foreach (Transform child in _layoutsParent.transform)
            {
                LayoutInfo layoutInfo = child.gameObject.GetComponent<LayoutInfo>();
                if (layoutInfo == null)
                {
                    Debug.LogError("Missing LayoutInfo script, aborting!");
                    return;
                }
                ConfigKeys(layoutInfo.KeysParent);
                ConfigKeys(_suggestionsParent);
                ConfigBackground(layoutInfo.Background);

                // Find the layout that'll be first used
                if (child.gameObject.activeInHierarchy)
                {
                    _curLayoutExtents = layoutInfo.Extents;
                }
            }
        }

        private void Start()
        {
            bool success = Init();
            if (success)
            {
                if (_printDebugInfo)
                {
                    Debug.Log("VirtualKeyboard init() successfully finished");
                }
            }
            else
            {
                Debug.LogError("VirtualKeyboard init() failed");
                return;
            }
            if (_reloadLayoutsOnStart)
            {
                LoadLayout(Locale, _pageCode, true);
            }
            // Only needs to connect keys to their callbacks
            else
            {
                ConfigLayouts();
                ConfigDisplayBar(_curLayoutExtents);
            }
        }
    }
}