# Unity Package: 3D Virtual Keyboard for ML2

> It's currently an alpha release that works with the experimental Unity build for ML2.

> Any changes can happen in the next few months, and we are aware that Unity API is undergoing changes too.

> For now, the only supported language is English.

> __This package uses Unity's new Universal Render Pipeline (URP), which cannot co-exist with the legacy Unity render pipeline in a project. Using this 3D keyboard package requires your project to completely switch to URP (instructions below)__

## Updates:

1/16/2022: It's been updated to use the 0.51.0 EC9 Unity Editor and the corresponding SDK of Version 0.51.0-220207.108753.abbfbd1. This is NOT backward compatible with older SDKs that are earlier than EC6, since the API calls are changed. See the section of "Unity SDK Refactor" in https://wiki.magicleap.com/pages/viewpage.action?spaceKey=SDK&title=Using+Unity+for+ML2+AOSP for details.

## Keyboard Interaction Explained

1. Typing on the keyboard

   This keyboard supports two interaction modes for typing:

   a. Raycasting. Use the ray to aim at the key you want to type on, and press the physical trigger on the ML2 controller to press down the key (see the first figure below);

   b. Stick. Use the tip of the virtual stick attached to the ML2 controller to touch and push down on the surface of the keys (see the second figure below).

<p align="middle">
  <img src="./Misc~/far.jpg" height="260" />
  <img src="./Misc~/near.jpg" height="260" />
</p>

   > - By default, the keyboard automatically switches between these two modes on the fly
   >   depends on the distance between the ML2 controller and the virtual keyboard.
   >   It switches to Raycasting when you are far away, and switches to Stick when you are close.
   >   In the Unity scene, the distance threshold for this switch is determined by the `_switchDist` parameter
   >   in the `InteractionManager` script on the `ControllerLogic` GameObject (which is attached to the controller's GameObject).
   > - On the same `InteractionManager` script, there is a parameter called `_inputTypeEnabled`.
   >   You can use this enum paramter to force the keyboard to only enable one interaction mode.
2. Moving the keyboard around

   This keyboard allows you to grab and move it around using the side handles.
   You need to first either aim at the side handle using Raycasting (first figure below)
   or overlap the Stick's tip with the sidehandle (second figure below), then hold down the trigger button of the ML2 controller to grab and move it.

<p align="middle">
  <img src="./Misc~/farHandle.jpg" height="230" />
  <img src="./Misc~/nearHandle.jpg" height="230" />
</p>

## Instructions on importing this package into your own Unity project:

1. Set up Unity environment for ML2 

   Set up your Unity editor and project following the Unity SDK team's instructions [here](https://developer.magicleap.cloud/learn/docs/guides/unity/getting-started/unity-getting-started).

   > This package was tested to work with the Unity SDK version of "0.51.0-220207.108753.abbfbd1 - February 07, 2022" (for 0.51.0 EC9 Unity Editor). We suggest you use this version or newer ones.

   > Make sure to install the SDK properly and switch build target to the correct one (called "Relish" as of Feb. 2022).

2. Clone or download this repository

3. Import this repository as a Unity package

   On Unity top menu, go to Window > Package Manager.

   In the Package Manager Window, open the dropdown next to "+" icon, select "Add package from disk". On the popup window, go to the repository you just downloaded and select "_this repo's folder_/package.json". Wait for the importation to finish. 

   > If Unity shows a "TMP Importer" popup now (or at a later step), please do click on "Import TMP Essentials" and wait for the process to finish. If the Unity hangs forever at this step, please force quit Unity, relaunch it and finish "Import TMP Esssentials" again. These "TMP Essentials" are necessary for displaying some UI elements used by the keyboard, so please do make sure they are imported properly.

   > You should not see any red error in Unity console after importation. If there is any error, it's likely that some sub-steps in Step 1 were not properly completed.

4. Set up Universal Render Pipeline (URP)

   > If your project is already using URP (e.g., you started the project using the URP template), this step is not needed.

   At this point, URP should have already been imported as a dependency of this keyboard package. We just need to set it up and switch the rendering method to URP from the legacy one. 

   > The URP instructions below are copy-pasted from https://docs.unity3d.com/Packages/com.unity.render-pipelines.universal@13.0/manual/InstallURPIntoAProject.html

   - To create a Universal Render Pipeline Asset:

      - In the Editor, go to the Project window.

      - Right-click in the Project window, and select Create > Rendering > URP Asset. Alternatively, navigate to the menu bar at the top, and select Assets > Create > Rendering > Universal Render Pipeline > Pipeline Asset.

      - You can either leave the default name for the new Universal Render Pipeline Asset, or type a new one.

   - Adding the Asset to your Graphics settings

      - Navigate to Edit > Project Settings... > Graphics

      - In the Scriptable Render Pipeline Settings field, add the Universal Render Pipeline Asset you created earlier. When you add the Universal Render Pipeline Asset, the available Graphics settings immediately change. Your Project is now using URP

## Instructions on using the keyboard:

1. An example scene

<p align="center">
  <img src="Misc~/importSampleScreenshot.png" height="600">
</p>

   On the Unity top menu, go to Window > Package Manager. As shown in the screenshot above, select this virtual keyboard package on the left side, you should see a dropdown menu called "Samples" on the right side. Expand it to reveal the sample called "Magic Leap Unity Keyboard Example Scene", click the button "Import" to import it into your project's Asset folder. Locate it in the Asset folder and open the example scene called "MagicLeapUnityKeyboard".

   It's a minimal example that contains the ML2 camera, the ML2 controller and a 3D keyboard. You can build and deploy to ML2 device to test.

   > Like mentioned earlier, if you see a popup asking you to "Import TMP Essentials", please do follow through and complete this one-time importation.

2. To import it into your own project

   - Drag the keyboard prefab in "Packages/_this keyboard package_/Runtime/Prefabs/Keyboard" into your scene

   - Set up ML2 camera and controller
    
       - If you've already set up ML2 camera and controller in you scene beforehand, drag the controller prefab in "Packages/_this keyboard package_/Runtime/Prefabs/ControllerLogic" into your scene and __attach it to the GameObject that represents the motion-tracked ML2 controller__

       - Otherwise if you don't have ML2 camera and controller set up, drag the controller prefab in "Packages/_this keyboard package_/Runtime/Prefabs/Controller" into your scene and place it at world origin (0, 0, 0). Drag the "Packages/_Magic Leap SDK_/Tools/Prefabs/Main Camera" prefab into your scene and place it at world origin as well.

       > Please make sure the ML2 "Main Camera" GameObject is the only camera in the scene that has the tag of "MainCamera", otherwise the billboarding behavior of the keyboard will be wrong. 

   - Make sure you have an "Event System" in your scene. If not, create one by selecting from main menu: "GameObject -> UI -> Event System". Without this, the blinking caret on the input field above the keyboard will not be displayed properly.

   > At this point you should have a functional keyboard that you can click with either Raycasting or Stick, and it should show what you typed in the input field on top.

3. How to connect key click events from the keyboard to your own app logic

   On the Keyboard prefab, you'll see a custom event called "PublishKeyEvent" in the "KeyboardManager.cs" script (names subject to change). Any time a key is pressed, this event will get invoked. Simply attach your own handler to this event to connect your app logic to the keyboard.

   > The example scene has an example connector handler attached to this keyboard event. The example handler just prints out information of the key click event. 

   The handler function needs to take in 4 input parameters:

   - arg0 (string): This is the character on the key being pressed for regular character keys (e.g., "w"). For suggestion keys, this is the selected word. For special keys (e.g., Shift), this is an empty string. 

   - arg1 (MagicLeapUI.KeyType): This enum is written in `KeyboardDefines.cs`, defining all the different types of keys. It's self-explainatory. For any "regular" character keys (e.g., "w"), it will be KeyType.kCharacter.

   - arg2 (bool): This boolean value indicates whether the key is double-clicked.

     > Each key on the keyboard has a script called `Clickable` attached,
       this script has a public float variable called `DoubleClickReactWindow`.
       When this variable is larger than 0, double-click is enabled and this number determines the system's reaction window
       in detecting the second click when interpreting a double-click input.
       If this variable is smaller than 0, double-click is disabled.

   - arg3 (string): All the content typed so far (should be the same as the text shown on the input field).

## Information on 3rd Party Software Usage:

This Unity package uses two pieces of 3rd paty software. Both are placed in "_this keyboard package_/Runtime/3rdParty/":

1. Shader Graph Custom Lighting

    > Location: "_this keyboard package_/Runtime/3rdParty/URP_ShaderGraphCustomLighting-main"
    >
    > [The original repo](https://github.com/Cyanilux/URP_ShaderGraphCustomLighting),
      commit SHA of the version used: 9cc5ad86242878e8e700617d288cf96b1a29ecda

2. Word Suggestion Algorithm from Gaia, namely Mozilla's Phone UX for the Boot to Geck (B2G) project

    > Location: "_this keyboard package_/Runtime/3rdParty/WordSuggestion"
    >
    > [Gaia's entire repo](https://github.com/mozilla-b2g/gaia)
    >
    > [Word suggestion algorithm](https://github.com/mozilla-b2g/gaia/blob/master/apps/keyboard/js/imes/latin/predictions.js),
      commit SHA of the version used: 18b322aef7f508ddcf0cc5fadf912d978a826407
    >
    > [English dictionary](https://github.com/mozilla-b2g/gaia/blob/master/apps/keyboard/js/imes/latin/dictionaries/en_us.dict),
      commit SHA of the version used: 6426618e1418b3534f3af460c96f9441f3730fdc

## Misc:

- On the keyboard prefab, there is a boolean value called "ExperimentalWordSuggestion". Use it to toggle on/off the word suggestion engine.

