using UnityEngine;
using UnityEditor;

namespace MagicLeap.Keyboard
{
#if UNITY_EDITOR
    [CustomEditor(typeof(KeyboardManager))]
    public class KeyboardManagerInspector : Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            KeyboardManager script = (KeyboardManager)target;
            if (GUILayout.Button("Reload Layouts"))
            {
                script.EditorReloadLayouts();
            }
        }
    }
#endif
}