using UnityEngine;
using UnityEditor;

namespace MagicLeap.Keyboard
{
#if UNITY_EDITOR
    [CustomEditor(typeof(VirtualKeyboardLayoutGen))]
    public class LayoutGeneratorInspector : Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            VirtualKeyboardLayoutGen layoutGenScript = (VirtualKeyboardLayoutGen)target;
            if (GUILayout.Button("Generate Layout"))
            {
                layoutGenScript.GenLanguageLayouts(layoutGenScript.Locale);
            }
        }
    }
#endif
}