#!/bin/bash
set -e

if [ ! -e flashall_amd.sh ]; then
  echo "ERROR: you must `cd` to a demophon_flash directory before running this script"
  exit 1
fi

tools_dir=/tmp/${USER}-flash-tools
mkdir -p ${tools_dir}

cat > ${tools_dir}/fastboot <<EOF
#!/bin/bash
if ! reenumerate 0x2c55,0xb201; then
  exit 1
fi

sleep 0.5

./Darwin/fastboot \$@ 1> >(grep --line-buffered -v "ERROR: could not clear") 2> >(grep --line-buffered -v "ERROR: Couldn't create a device interface iterator")
exit \${PIPESTATUS[0]}
EOF

chmod a+x ${tools_dir}/fastboot

cat > ${tools_dir}/usbrecovery_host <<EOF
#!/bin/bash
# recovery mode is not supported on Mac
exit 1
EOF

chmod a+x ${tools_dir}/usbrecovery_host

cat > ${tools_dir}/lsusb <<EOF
#!/bin/bash

function bad_args {
  echo "ERROR: Unsupported lsusb arguments '\$@'"
  exit 1
}

want_vid=

if [[ \$# != 0 ]]; then
  if [[ \$# == 2 ]] && [[ \$1 == "-d" ]]; then
    want_vid=\${2/:*}
    if [[ \$2 != "\${want_vid}:" ]]; then
      bad_args \$@
    fi
  else
    bad_args \$@
  fi
else
  echo NARGS: \$#
fi

# Bus 004 Device 122: ID 18d1:0223 Google Inc. demophon_aosp

ioreg -c AppleUSBDevice | grep -e idVendor -e idProduct | cut -d = -f 2 | paste -d " " - - | while read pid vid; do
  vid=\$(printf "%04x" \$vid)
  pid=\$(printf "%04x" \$pid)

  if [[ -n \${want_vid} ]] && [[ \${vid} != \${want_vid} ]]; then
    continue
  fi

  printf "Bus 000 Device 000: ID %s:%s unknown\n" \$vid \$pid
done

EOF

chmod a+x ${tools_dir}/lsusb

cat > ${tools_dir}/stat <<EOF
#!/bin/bash

if [[ \$# == 2 ]] && [[ \$1 == "-c%s" ]]; then
  /usr/bin/stat -f %z \$2
else
  echo "ERROR: Unsupported stat arguments: '\$@'"
  exit 1
fi
EOF

chmod a+x ${tools_dir}/stat

if [ ! -e ${tools_dir}/reenumerate ]; then
  curl -fn https://artifactory.magicleap.com/artifactory/kraken-verify-deps/darwin_flash/reenumerate > ${tools_dir}/reenumerate.tmp
  chmod a+x ${tools_dir}/reenumerate.tmp
  mv ${tools_dir}/reenumerate.tmp ${tools_dir}/reenumerate
fi

export darwin_flash_tools_dir=${tools_dir}
export PATH=${darwin_flash_tools_dir}:${PWD}/Darwin:${PATH}
bash flashall_amd.sh $@
